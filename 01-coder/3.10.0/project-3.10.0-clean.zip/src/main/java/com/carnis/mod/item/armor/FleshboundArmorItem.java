package com.carnis.mod.item.armor;

import com.carnis.mod.client.renderer.FleshboundArmorRenderer;
import com.carnis.mod.init.ModArmorMaterials;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;

/**
 * Плотевая броня (задача броня 3.10.0).
 *
 * <p>Четыре части комплекта: шлем, нагрудник, поножи, ботинки. Полный сет
 * даёт владельцу проход сквозь тело улья — тем же механизмом, что и у
 * заражённых мобов (см. {@code HiveBody#mayPhase}). Без полного сета броня
 * остаётся просто прочной кожей.
 */
public class FleshboundArmorItem extends ArmorItem implements GeoItem {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public FleshboundArmorItem(Type type, Properties properties) {
        super(ModArmorMaterials.FLESHBOUND, type, properties);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) { }

    public static boolean isFullSet(LivingEntity entity) {
        return piece(entity, EquipmentSlot.HEAD, ArmorItem.Type.HELMET)
                && piece(entity, EquipmentSlot.CHEST, ArmorItem.Type.CHESTPLATE)
                && piece(entity, EquipmentSlot.LEGS, ArmorItem.Type.LEGGINGS)
                && piece(entity, EquipmentSlot.FEET, ArmorItem.Type.BOOTS);
    }

    private static boolean piece(LivingEntity entity, EquipmentSlot slot, ArmorItem.Type expected) {
        ItemStack stack = entity.getItemBySlot(slot);
        return stack.getItem() instanceof FleshboundArmorItem armor && armor.getType() == expected;
    }

    @Override public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private FleshboundArmorRenderer renderer;
            @Override public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                    EquipmentSlot slot, HumanoidModel<?> original) {
                if (renderer == null) renderer = new FleshboundArmorRenderer();
                renderer.prepForRender(entity, stack, slot, original);
                return renderer;
            }
        });
    }
}
