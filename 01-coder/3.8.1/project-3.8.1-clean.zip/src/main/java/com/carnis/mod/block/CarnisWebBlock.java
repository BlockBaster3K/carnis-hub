package com.carnis.mod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.CobwebBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Temporary Carnis-grown snare used by Raptorial Arachnid pounce.
 *
 * Lifecycle: {@link #onPlace} schedules the first tick, {@link #tick} re-schedules
 * itself, so the snare removes itself after roughly {@link #LIFETIME_TICKS}.
 * Also decays on random ticks, which keeps it from lingering if a scheduled tick
 * is ever dropped (chunk unload, /setblock).
 *
 * Notes on the 1.20.1 contracts this class had to respect:
 * - {@code Level.getBlockState(pos)} returns {@code BlockStateBase}, whose
 *   {@code is(Block)} takes a {@code Block}, so the receiver must be a state
 *   ({@code state.is(this)}) and not the block instance;
 * - a plain {@code Block} does not tick by itself: it needs a scheduled tick
 *   ({@code scheduleTick}) or {@code randomTick} plus {@code randomTicks()} in
 *   the properties. {@code CobwebBlock} sets neither, so both are wired here.
 */
public final class CarnisWebBlock extends CobwebBlock {
    /** Single scheduled-tick step. ~2 s. */
    private static final int STEP_TICKS = 40;
    /** How long the snare stays before it dissolves: ~10 s. */
    private static final int LIFETIME_TICKS = 200;

    public CarnisWebBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public void onPlace(BlockState state, net.minecraft.world.level.Level level, BlockPos pos,
                        BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (!level.isClientSide && !state.is(oldState.getBlock())) {
            level.scheduleTick(pos, this, STEP_TICKS);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.is(this)) return;
        if (level.getBlockState(pos).is(this)) {
            if (random.nextInt(5) == 0) {
                level.removeBlock(pos, false);
                return;
            }
        }
        level.scheduleTick(pos, this, STEP_TICKS);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.is(this)) level.removeBlock(pos, false);
    }

    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return true;
    }
}
