# ПРОМПТ ХУДОЖНИКУ — Доработка infected_spider_b / infected_creeper_b для 3.8.1

**Источник:** Архитектор (Дирижер). Передать Художнику.

## Что нужно сделать

Создать / доработать 2 модели для релиза 3.8.1:

| Модель | Геометрия | Текстура | Glowmask |
|--------|-----------|----------|----------|
| `infected_spider_b` | `04-artist/models/entity/infected_spider_b.geo.json` | `04-artist/textures/entity/infected_spider_b.png` (64×64) | `04-artist/textures/entity/infected_spider_b_glowmask.png` |
| `infected_creeper_b` | `04-artist/models/entity/infected_creeper_b.geo.json` | `04-artist/textures/entity/infected_creeper_b.png` (64×64) | `04-artist/textures/entity/infected_creeper_b_glowmask.png` |

Файлы **не найдены в workspace** — нужно создать их с нуля.

---

## 1. Rig alignment — привести имена костей к старому ригу

Модели должны использовать те же имена костей, что и существующие модели в пакете (иначе core9 анимации не применятся).

| Что менять | Было (неправильно) | Стало (правильно) |
|------------|-------------------|-------------------|
| Кость лезвия/оружия | `scythe_*` | `bone_blade` |
| Правая рука | `arm_right` | `right_arm` |
| Правая нога | `leg_right` | `right_leg` |
| Левая рука | `arm_left` | `left_arm` |
| Левая нога | `leg_left` | `left_leg` |

Проверить: `geo_check.py` → код 0.

---

## 2. Glowmask — Правило R-3

| Требование | Детали |
|------------|--------|
| Имя файла | `_glowmask.png` (не `_glow.png`) |
| Цвета | Ровно 2 цвета: прозрачный `(0,0,0,0)` + `(255,92,57,255)` |
| Alpha | 255 для не-прозрачных пикселей |
| Цветов вне палитры | 0 |

---

## 3. Проверка перед сдачей

1. `geo_check.py` на каждой модели → код 0
2. Текстуры 64×64, A3R1 норма
3. Glowmask: `_glowmask.png`, ровно 2 цвета R-3, alpha 255
4. Имена костей совпадают со старым ригом (таблица выше)

---

## Отчёт

После завершения написать в файл `00-board/agents/artist.md`:

> infected_spider_b и infected_creeper_b готовы: rig align под старый риг, glowmask `_glowmask.png`, цвета R-3, geo_check → код 0.

Также дублировать ответ в чат Пользователю.

## Связь с Архитектором

Всё, что пишешь Пользователю в ответ в чате, дублировать в файл `00-board/agents/artist.md`.
