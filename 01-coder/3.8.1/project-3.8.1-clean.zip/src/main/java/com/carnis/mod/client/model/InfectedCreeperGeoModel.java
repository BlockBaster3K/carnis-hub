package com.carnis.mod.client.model;

import com.carnis.mod.entity.InfectedCreeperEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/**
 * The model resolves the geometry, texture, and animation resources.
 *
 * Variant B is gameplay-distinct and now ships its own art: separate geometry,
 * texture and animation set under the "_b" suffix. The choice is made per
 * entity through isVariantA(), exactly as the zombie and skeleton models do.
 */
public final class InfectedCreeperGeoModel extends GeoModel<InfectedCreeperEntity> {
    @Override public ResourceLocation getModelResource(InfectedCreeperEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA()
                ? "geo/entity/infected_creeper.geo.json"
                : "geo/entity/infected_creeper_b.geo.json");
    }
    @Override public ResourceLocation getTextureResource(InfectedCreeperEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA()
                ? "textures/entity/infected_creeper.png"
                : "textures/entity/infected_creeper_b.png");
    }
    @Override public ResourceLocation getAnimationResource(InfectedCreeperEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA()
                ? "animations/entity/infected_creeper.animation.json"
                : "animations/entity/infected_creeper_b.animation.json");
    }
}
