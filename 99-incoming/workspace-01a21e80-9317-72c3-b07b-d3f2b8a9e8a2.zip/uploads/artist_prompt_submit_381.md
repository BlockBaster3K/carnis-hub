# ПРОМПТ ХУДОЖНИКУ — Передать модели `_b` в репозиторий 3.8.1

**Источник:** Архитектор (Дирижер). Передать Художнику лично.

## Что нужно сделать

Закоммитить и запушить 2 отсутствующие модели `_b` + текстуры + glowmask в репозиторий.

## Какие файлы

| Модель | Геометрия | Текстура (64×64) | Glowmask (`_glowmask.png`, R-3) |
|--------|-----------|------------------|----------------------------------|
| `infected_spider_b` | `04-artist/models/entity/infected_spider_b.geo.json` | `04-artist/textures/entity/infected_spider_b.png` | `04-artist/textures/entity/infected_spider_b_glowmask.png` |
| `infected_creeper_b` | `04-artist/models/entity/infected_creeper_b.geo.json` | `04-artist/textures/entity/infected_creeper_b.png` | `04-artist/textures/entity/infected_creeper_b_glowmask.png` |

## Проверка перед сдачей

1. `geo_check.py` на каждой модели → код 0
2. Rig align под старый риг (`bone_blade`, `right_arm`/`right_leg`, `left_arm`/`left_leg` — не `scythe_*`, `arm_right`/`leg_right`)
3. Glowmask: ровно 2 цвета — прозрачный `(0,0,0,0)` + `(255,92,57,255)`, alpha 255

## Git

- `git fetch` + `git rebase` перед коммитом
- Коммит поимённо (не `git add -A` вслепую)
- Запушить в origin

## Очистка workspace

После коммита и пуша:
- Удалите `__pycache__`, временные файлы, кэши, build-папки в своей рабочей директории
- Не трогайте tracked-файлы и чужие зоны

## Отчёт

После завершения отписаться в файл `00-board/agents/artist.md`:

| Что | Статус | Комментарий |
|-----|--------|-------------|
| infected_spider_b закоммичен и запушен | ✅/❌ | |
| infected_creeper_b закоммичен и запушен | ✅/❌ | |
| Workspace очищен | ✅/❌ | |

Также дублировать ответ в чат Пользователю.

## Связь с Архитектором

Всё, что пишешь Пользователю в ответ в чате, дублировать в файл `00-board/agents/artist.md`.
