package com.carnis.mod.entity;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Stable, replaceable variant stat modifiers; synchronized variant ID is the single source of truth. */
final class VariantAttributes {
    private VariantAttributes() { }

    static void apply(LivingEntity entity, InfectedVariant variant) {
        String kind = entity.getType().toString();
        for (Attribute attribute : new Attribute[]{Attributes.MAX_HEALTH, Attributes.ATTACK_DAMAGE,
                Attributes.MOVEMENT_SPEED, Attributes.FOLLOW_RANGE, Attributes.ARMOR,
                Attributes.KNOCKBACK_RESISTANCE}) {
            AttributeInstance instance = entity.getAttribute(attribute);
            if (instance != null) instance.removeModifier(id(kind, attribute));
        }
        if (entity instanceof InfectedZombieEntity) {
            if (variant == InfectedVariant.A) add(entity, Attributes.ATTACK_DAMAGE, kind, 0.50D, AttributeModifier.Operation.MULTIPLY_TOTAL);
            else add(entity, Attributes.MOVEMENT_SPEED, kind, 0.30D, AttributeModifier.Operation.MULTIPLY_TOTAL);
        } else if (entity instanceof InfectedSkeletonEntity) {
            if (variant == InfectedVariant.A) {
                add(entity, Attributes.FOLLOW_RANGE, kind, 4.0D, AttributeModifier.Operation.ADDITION);
                add(entity, Attributes.ATTACK_DAMAGE, kind, 0.25D, AttributeModifier.Operation.MULTIPLY_TOTAL);
            } else {
                add(entity, Attributes.MOVEMENT_SPEED, kind, 0.25D, AttributeModifier.Operation.MULTIPLY_TOTAL);
                add(entity, Attributes.ATTACK_DAMAGE, kind, 0.25D, AttributeModifier.Operation.MULTIPLY_TOTAL);
                add(entity, Attributes.ARMOR, kind, 4.0D, AttributeModifier.Operation.ADDITION);
            }
        } else if (entity instanceof InfectedSpiderEntity) {
            if (variant == InfectedVariant.A) {
                add(entity, Attributes.MAX_HEALTH, kind, -0.20D, AttributeModifier.Operation.MULTIPLY_TOTAL);
                add(entity, Attributes.ATTACK_DAMAGE, kind, 2.0D, AttributeModifier.Operation.ADDITION);
            } else {
                add(entity, Attributes.MOVEMENT_SPEED, kind, -0.25D, AttributeModifier.Operation.MULTIPLY_TOTAL);
                add(entity, Attributes.ARMOR, kind, 12.0D, AttributeModifier.Operation.ADDITION);
                add(entity, Attributes.KNOCKBACK_RESISTANCE, kind, 1.0D, AttributeModifier.Operation.ADDITION);
            }
        } else if (entity instanceof InfectedCreeperEntity) {
            if (variant == InfectedVariant.A) {
                add(entity, Attributes.MOVEMENT_SPEED, kind, 0.25D, AttributeModifier.Operation.MULTIPLY_TOTAL);
                add(entity, Attributes.FOLLOW_RANGE, kind, 12.0D, AttributeModifier.Operation.ADDITION);
            } else {
                add(entity, Attributes.MOVEMENT_SPEED, kind, 1.0D, AttributeModifier.Operation.MULTIPLY_TOTAL);
            }
        }
    }

    private static void add(LivingEntity entity, Attribute attribute, String kind, double amount,
                            AttributeModifier.Operation operation) {
        AttributeInstance instance = entity.getAttribute(attribute);
        if (instance != null) instance.addTransientModifier(new AttributeModifier(id(kind, attribute),
                "Carnis combat variant", amount, operation));
    }

    private static UUID id(String kind, Attribute attribute) {
        return UUID.nameUUIDFromBytes((kind + ":carnis_variant:" + attribute).getBytes(StandardCharsets.UTF_8));
    }
}
