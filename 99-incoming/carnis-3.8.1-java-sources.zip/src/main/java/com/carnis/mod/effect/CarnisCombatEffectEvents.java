package com.carnis.mod.effect;

import com.carnis.mod.CarnisMod;
import com.carnis.mod.init.ModEffects;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CarnisMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CarnisCombatEffectEvents {
    private CarnisCombatEffectEvents() { }

    @SubscribeEvent
    public static void amplifyVulnerableTarget(LivingHurtEvent event) {
        var effect = event.getEntity().getEffect(ModEffects.VULNERABILITY.get());
        if (effect != null) {
            float multiplier = 1.20F + 0.10F * effect.getAmplifier();
            event.setAmount(event.getAmount() * multiplier);
        }
    }

    @SubscribeEvent
    public static void haltParalyzedMob(LivingEvent.LivingTickEvent event) {
        if (event.getEntity().level().isClientSide
                || event.getEntity().getEffect(ModEffects.PARALYSIS.get()) == null
                || !(event.getEntity() instanceof Mob mob)) return;
        mob.getNavigation().stop();
        var velocity = mob.getDeltaMovement();
        mob.setDeltaMovement(0.0D, velocity.y, 0.0D);
    }
}
