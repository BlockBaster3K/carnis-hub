# ПРОМПТ ХУДОЖНИКУ — Модели infected_spider_b и infected_creeper_b

**Источник:** Архитектор (Дирижер). Передать Художнику.

## Контекст

Собирается пакет 3.8.1 с 8 моделями зараженных мобов (Зомби×2, Скелет×2, Паук×2, Крипер×2). В репозитории уже есть:
- infected_zombie, infected_zombie_b
- infected_skeleton, infected_skeleton_b
- infected_spider (1 вариация)
- infected_creeper (1 вариация)

**Нужно создать вторую вариацию для паука и крипера.**

## Файлы для создания (по каждому существу)

### 1. infected_spider_b

| Файл | Путь | Требования |
|------|------|------------|
| Геометрия | `04-artist/models/entity/infected_spider_b.geo.json` | Geckolib-формат, валидный JSON, UV в пределах текстуры, texture_width/height == размер PNG, битых pivot нет, кости без родителя — нет, дублей имён — нет |
| Текстура | `04-artist/textures/entity/infected_spider_b.png` | A3R1 норма: 64×64, RGBA, alpha только 0/255, ровно 7 непрозрачных цветов, силает не менять |
| Glowmask | `04-artist/textures/entity/infected_spider_b_glow.png` | Правило Р-3: ровно 2 цвета — прозрачный `(0,0,0,0)` и `(255,92,57,255)`, alpha 255, 0 цветов вне палитры |

### 2. infected_creeper_b

| Файл | Путь | Требования |
|------|------|------------|
| Геометрия | `04-artist/models/entity/infected_creeper_b.geo.json` | Geckolib-формат, валидный JSON, UV в пределах текстуры, texture_width/height == размер PNG, битых pivot нет, кости без родителя — нет, дублей имён — нет |
| Текстура | `04-artist/textures/entity/infected_creeper_b.png` | A3R1 норма: 64×64, RGBA, alpha только 0/255, ровно 7 непрозрачных цветов, силает не менять |
| Glowmask | `04-artist/textures/entity/infected_creeper_b_glow.png` | Правило Р-3: ровно 2 цвета — прозрачный `(0,0,0,0)` и `(255,92,57,255)`, alpha 255, 0 цветов вне палитры |

## Проверка перед сдачей

1. Запустить `04-artist/tools/geo_check.py` (или аналогичный инструмент) на каждой модели — код 0.
2. Проверить размер текстур: 64×64.
3. Проверить glowmask: ровно 2 цвета, alpha 255, ничего вне палитры.
4. Убедиться, что модели отличаются от существующих `infected_spider` / `infected_creeper` (вариация_b должна быть отличима).

## Связь с Архитектором

Всё, что пишешь Пользователю в ответ в чате, дублировать в файл `00-board/agents/artist.md`.

После создания файлов написать: «infected_spider_b и infected_creeper_b созданы, geo_check → код 0».

## Запущено ранее (для контекста)

- Интегратор создал `tools/accept_3.8.1.py` — обёртка гейта
- §4b гейта показал дефект: у 4 существ (включая infected_spider и infected_creeper) нет полного набора анимаций
- Решение по анимациям пока не принято — сначала нужны модели
