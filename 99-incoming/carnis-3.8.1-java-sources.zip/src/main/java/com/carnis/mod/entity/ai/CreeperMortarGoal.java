package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.CarnisSporeBombEntity;
import com.carnis.mod.entity.InfectedCreeperEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/** Variant-A spore mortar. Lobs a three-bomb CarnisSporeBombEntity salvo from 10–16 blocks. */
public final class CreeperMortarGoal extends Goal {
    private final InfectedCreeperEntity creeper;
    private int cooldown;
    public CreeperMortarGoal(InfectedCreeperEntity creeper) {
        this.creeper = creeper;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }
    @Override public boolean canUse() {
        if (cooldown > 0) cooldown--;
        LivingEntity target = creeper.getTarget();
        if (creeper.isVariantB() || target == null || !target.isAlive()) return false;
        double d = creeper.distanceToSqr(target);
        return cooldown == 0 && d >= 100.0D && d <= 256.0D;
    }
    @Override public boolean canContinueToUse() {
        LivingEntity target = creeper.getTarget();
        return !creeper.isVariantB() && target != null && target.isAlive()
                && creeper.distanceToSqr(target) >= 100.0D && creeper.distanceToSqr(target) <= 324.0D;
    }
    @Override public void start() {
        creeper.getNavigation().stop();
        creeper.triggerCombatAnimation("anchor");
    }
    @Override public void tick() {
        LivingEntity target = creeper.getTarget();
        if (target == null || !(creeper.level() instanceof ServerLevel server)) return;
        creeper.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (creeper.tickCount % 20 != 0) return;
        double d = creeper.distanceToSqr(target);
        if (d < 100.0D || d > 256.0D) return;
        creeper.triggerCombatAnimation("mortar_fire");
        double dx = target.getX() - creeper.getX(), dz = target.getZ() - creeper.getZ();
        double length = Math.max(0.001D, Math.sqrt(dx * dx + dz * dz));
        double sideX = -dz / length, sideZ = dx / length;
        launch(server, target.getX(), target.getY() + 0.5D, target.getZ());
        launch(server, target.getX() + sideX * 1.8D, target.getY() + 0.5D, target.getZ() + sideZ * 1.8D);
        launch(server, target.getX() - sideX * 1.8D, target.getY() + 0.5D, target.getZ() - sideZ * 1.8D);
        server.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, target.getX(), target.getY() + 0.7D, target.getZ(),
                12, .35D, .2D, .35D, .02D);
        cooldown = 100;
    }
    @Override public void stop() { creeper.getNavigation().stop(); }
    private void launch(ServerLevel level, double targetX, double targetY, double targetZ) {
        CarnisSporeBombEntity bomb = new CarnisSporeBombEntity(level, creeper);
        bomb.setPos(creeper.getX(), creeper.getEyeY() - 0.1D, creeper.getZ());
        double dx = targetX - creeper.getX();
        double dy = targetY - creeper.getEyeY();
        double dz = targetZ - creeper.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        bomb.shoot(dx, dy + horizontal * 0.18D, dz, 0.95F, 2.0F);
        level.addFreshEntity(bomb);
    }
}
