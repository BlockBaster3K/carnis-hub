package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.InfectedSkeletonEntity;
import com.carnis.mod.entity.CarnisPiercingArrow;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Variant-A strict-range sniper: charges for 50 ticks, keeps 18–24 block spacing, and fires a level piercing arrow. */
public final class InfectedSkeletonSniperGoal extends Goal {
    private final InfectedSkeletonEntity skeleton;
    private int chargeTicks;
    private int cooldown;
    public InfectedSkeletonSniperGoal(InfectedSkeletonEntity skeleton) {
        this.skeleton = skeleton;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }
    @Override public boolean canUse() {
        LivingEntity target = skeleton.getTarget();
        return skeleton.isVariantA() && target != null && target.isAlive();
    }
    @Override public boolean canContinueToUse() { return canUse(); }
    @Override public void start() { chargeTicks = 0; cooldown = 0; }
    @Override public void stop() { skeleton.getNavigation().stop(); chargeTicks = 0; }
    @Override public void tick() {
        LivingEntity target = skeleton.getTarget();
        if (target == null || !target.isAlive()) return;
        skeleton.getLookControl().setLookAt(target, 30.0F, 30.0F);
        double distance = skeleton.distanceTo(target);
        if (distance < 6.0D) {
            Vec3 away = skeleton.position().subtract(target.position()).normalize();
            skeleton.getNavigation().moveTo(skeleton.getX() + away.x * 8.0D, skeleton.getY(),
                    skeleton.getZ() + away.z * 8.0D, 1.45D);
            chargeTicks = 0;
            return;
        }
        if (distance < 18.0D) {
            skeleton.getNavigation().moveTo(target, 1.0D);
            chargeTicks = 0;
            return;
        }
        if (distance > 24.0D) {
            skeleton.getNavigation().moveTo(target, 1.0D);
            chargeTicks = 0;
            return;
        }
        skeleton.getNavigation().stop();
        if (!skeleton.hasLineOfSight(target)) { chargeTicks = 0; return; }
        if (cooldown > 0) { cooldown--; return; }
        if (++chargeTicks >= 50) {
            fire(target);
            chargeTicks = 0;
            cooldown = 35;
        }
    }
    private void fire(LivingEntity target) {
        if (!(skeleton.level() instanceof ServerLevel server)) return;
        CarnisPiercingArrow arrow = new CarnisPiercingArrow(server, skeleton, 2.0F);
        arrow.setNoGravity(true);
        arrow.setPierceLevel((byte) 3);
        arrow.setBaseDamage(6.0D);
        Vec3 aim = target.getEyePosition().subtract(skeleton.getEyePosition()).normalize();
        arrow.shoot(aim.x, aim.y, aim.z, 3.4F, 0.0F);
        arrow.setPos(skeleton.getX(), skeleton.getEyeY() - 0.1D, skeleton.getZ());
        server.addFreshEntity(arrow);
        skeleton.triggerCombatAnimation("sniper_shot");
    }
}
