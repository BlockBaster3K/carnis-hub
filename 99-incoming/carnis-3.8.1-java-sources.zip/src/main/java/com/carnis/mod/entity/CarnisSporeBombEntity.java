package com.carnis.mod.entity;

import com.carnis.mod.event.NeuroArmorEventHandler;
import com.carnis.mod.init.ModEffects;
import com.carnis.mod.init.ModEntities;
import com.carnis.mod.init.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.network.NetworkHooks;

/** Lobbed projectile used by Spore Sac Mortar. It bursts into a short-lived Carnis spore cloud. */
public final class CarnisSporeBombEntity extends ThrowableItemProjectile {
    public CarnisSporeBombEntity(EntityType<? extends CarnisSporeBombEntity> type, Level level) {
        super(type, level);
    }
    public CarnisSporeBombEntity(Level level, LivingEntity owner) {
        super(ModEntities.CARNIS_SPORE_BOMB.get(), owner, level);
    }
    @Override protected Item getDefaultItem() { return ModItems.CARNIS_SPORE.get(); }
    @Override protected boolean canHitEntity(Entity entity) {
        return super.canHitEntity(entity) && !NeuroArmorEventHandler.isHiveEntity(entity)
                && (!(entity instanceof net.minecraft.world.entity.player.Player player)
                || (!player.isCreative() && !player.isSpectator()));
    }
    @Override public void tick() {
        super.tick();
        if (level().isClientSide && !isRemoved()) {
            level().addParticle(ParticleTypes.SPORE_BLOSSOM_AIR, getX(), getY(), getZ(), 0.0D, 0.01D, 0.0D);
        }
        if (!level().isClientSide && tickCount > 100) burst();
    }
    @Override protected void onHitEntity(EntityHitResult hit) {
        super.onHitEntity(hit);
        if (level() instanceof ServerLevel server && hit.getEntity() instanceof LivingEntity living
                && living.hurt(server.damageSources().thrown(this, getOwner()), 3.0F)) {
            living.addEffect(new net.minecraft.world.effect.MobEffectInstance(ModEffects.VENOM.get(), 60, 0));
        }
    }
    @Override protected void onHit(HitResult hit) {
        super.onHit(hit);
        if (!level().isClientSide) burst();
    }
    private void burst() {
        if (!(level() instanceof ServerLevel server) || isRemoved()) return;
        HiveSporeCloudEntity cloud = new HiveSporeCloudEntity(ModEntities.HIVE_SPORE_CLOUD.get(), server);
        if (getOwner() instanceof LivingEntity owner) cloud.setOwner(owner);
        cloud.setPos(getX(), getY(), getZ());
        cloud.setRadius(1.8F);
        cloud.setDuration(60);
        cloud.setWaitTime(0);
        cloud.setRadiusPerTick(-0.015F);
        server.addFreshEntity(cloud);
        server.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, getX(), getY() + 0.2D, getZ(),
                16, 0.25D, 0.2D, 0.25D, 0.03D);
        discard();
    }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
