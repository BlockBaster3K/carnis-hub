# 3.4.10 — предметы horror p2 (частичная партия: 8 PNG из 21)

## Сделано
Восемь предметных иконок: лекарство, два дротика, журнал и четыре иконки комплекта нейрорезонатора. Модели, надеваемые текстуры брони и код не менялись. Пакет содержит PNG по путям `assets/carnis/textures/item/`, манифест и вспомогательный просмотр. Исходники сохранены в `analysis_horror_3410/baseline_changed_assets/textures/item/`.

| PNG | Размер | Байт | SHA-256 |
|---|---:|---:|---|
| `textures/item/antibiotics.png` | 64×64 RGBA | 3048 | `18871f643334ce32044955e4035146ffbdddcc519336b8f92b2ee1f47e4f00c2` |
| `textures/item/purification_dart.png` | 64×64 RGBA | 2083 | `29c1c6b76960f30d9d8b3f3b4ed6996e7fb374896dc4c83cf074d52ce9a74403` |
| `textures/item/viral_dart.png` | 64×64 RGBA | 2516 | `4513f90c38d76c04412b113d51a7dd4c8aa607b7d10826c5000396967aadbd73` |
| `textures/item/research_journal.png` | 64×64 RGBA | 5023 | `defb01ec143f5c1c970ec2bc62bd02eeed12521cbc04847cd9dd3e25ecccf057` |
| `textures/item/neuro_resonator_helmet.png` | 64×64 RGBA | 6768 | `3ab09c616ecc4f98679ea66bd1bdd0a874d9f53ec90a9045f47115bf8210d87c` |
| `textures/item/neuro_resonator_chestplate.png` | 64×64 RGBA | 4645 | `a79eb128c4ec4985b24f6e0b694c7687f25a915d492112b65d7cf8c47e8930d0` |
| `textures/item/neuro_resonator_leggings.png` | 64×64 RGBA | 6125 | `48ef017f23d81b770b4e061747fd5e5eef857dd0031837971fa0c7b058075dcf` |
| `textures/item/neuro_resonator_boots.png` | 64×64 RGBA | 4308 | `1b67323aafd0d1204b47cc80a064ae6b366c3ace342536b5514b987258972697` |

Оригиналы антибиотика и дротиков — 16×16; журнала и четырёх иконок брони — 32×32. Новые файлы 64×64; `manifest.json` содержит исходные размеры и хеши PNG и моделей. Просмотр — на тёмном и светлом фоне, а также имитация 16 px.

## Ограничения
- Партия предложена к приёмке, не объявляется принятой. Это иконки, не текстуры брони на модели игрока.
- В Minecraft не проверены инвентарь, дроп, предмет в руке и отображение в других UI; проверка — в общем пакетном тесте. При 16 px мелкая фактура дротиков и журнала упрощается.
- Проверены прозрачные границы, связные компоненты по альфе с сохранением раздельных ботинок, ярко-зелёный spill (пороговый тест); отсутствие всех визуальных дефектов не доказано.
- Ведро `tainted_sludge_bucket` не включено: ручка в тесте 16 px слишком тонкая. `creeping_tendrils` отложен до работы над существами по указанию заказчика.

## Осталось
Партия p1 из 7 PNG принята заказчиком, p2 из 8 PNG направлена на приёмку. Из 21 предметных PNG ещё 6 не сданы:

- `bio_purifier.png`
- `bio_purifier_geo.png`
- `bio_purifier_glowmask.png`
- `creeping_tendrils.png`
- `pneumatic_inoculator_geo.png`
- `tainted_sludge_bucket.png`

Файлы purifier и inoculator — UV-атласы/маска; требуют отдельной проверки совместимости с реальными geo/renderer, не простого рисунка иконки. После предметов — существа и geo, далее armor/gui/particle и прочие категории.

LOCK 9/9 проверен по baseline после установки. Ни один файл 35-текстурного Gate A этой партией не затронут.
