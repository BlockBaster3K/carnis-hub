package com.carnis.mod.effect;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

/** Harmful Carnis effect with a small periodic damage pulse. */
public final class PeriodicDamageMobEffect extends MobEffect {
    private final int intervalTicks;
    private final float damage;

    public PeriodicDamageMobEffect(int color, int intervalTicks, float damage) {
        super(MobEffectCategory.HARMFUL, color);
        this.intervalTicks = Math.max(1, intervalTicks);
        this.damage = Math.max(0.0F, damage);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration > 0 && duration % intervalTicks == 0;
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!(entity.level() instanceof ServerLevel server) || damage <= 0.0F) return;
        entity.hurt(server.damageSources().magic(), damage * (1.0F + 0.25F * amplifier));
    }
}
