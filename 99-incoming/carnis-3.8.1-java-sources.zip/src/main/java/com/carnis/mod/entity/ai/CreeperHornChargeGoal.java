package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.InfectedCreeperEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Variant-B horn charge: 16-tick tell, then a double-speed line break with a focused impact burst. */
public final class CreeperHornChargeGoal extends Goal {
    private final InfectedCreeperEntity creeper;
    private int cooldown;
    private int windup;
    private int runTicks;
    private boolean charging;
    public CreeperHornChargeGoal(InfectedCreeperEntity creeper) {
        this.creeper = creeper;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }
    @Override public boolean canUse() {
        if (cooldown > 0) cooldown--;
        LivingEntity target = creeper.getTarget();
        return creeper.isVariantB() && cooldown == 0 && !charging && target != null && target.isAlive()
                && creeper.distanceToSqr(target) <= 196.0D;
    }
    @Override public boolean canContinueToUse() {
        LivingEntity target = creeper.getTarget();
        return charging && target != null && target.isAlive() && runTicks < 30;
    }
    @Override public void start() {
        charging = true;
        windup = 16;
        runTicks = 0;
        creeper.getNavigation().stop();
        creeper.triggerCombatAnimation("horn_charge");
    }
    @Override public void tick() {
        LivingEntity target = creeper.getTarget();
        if (target == null) return;
        creeper.getLookControl().setLookAt(target, 45.0F, 45.0F);
        if (windup > 0) {
            creeper.getNavigation().stop();
            windup--;
            return;
        }
        runTicks++;
        creeper.setSprinting(true);
        creeper.getNavigation().moveTo(target, 1.0D);
        Vec3 delta = target.position().subtract(creeper.position());
        if (delta.lengthSqr() <= 4.0D) {
            impact(target);
            charging = false;
        }
    }
    @Override public void stop() {
        if (charging) cooldown = 100;
        charging = false;
        creeper.setSprinting(false);
        creeper.getNavigation().stop();
    }
    private void impact(LivingEntity target) {
        if (!(creeper.level() instanceof ServerLevel server)) return;
        Vec3 direction = target.position().subtract(creeper.position());
        if (direction.horizontalDistanceSqr() < 1.0E-8D) direction = new Vec3(0, 0, 1);
        target.hurt(server.damageSources().mobAttack(creeper), 8.0F);
        target.knockback(1.4D, -direction.x, -direction.z);
        if (target instanceof Player player) player.getCooldowns().addCooldown(Items.SHIELD, 100);
        Vec3 forward = new Vec3(direction.x, 0.0D, direction.z).normalize();
        for (LivingEntity nearby : server.getEntitiesOfClass(LivingEntity.class,
                creeper.getBoundingBox().inflate(4.0D, 1.2D, 4.0D),
                candidate -> candidate != creeper && candidate != target && candidate.isAlive()
                        && HiveSwarmCoordinator.validTarget(creeper, candidate))) {
            Vec3 offset = nearby.position().subtract(creeper.position());
            Vec3 horizontal = new Vec3(offset.x, 0.0D, offset.z);
            if (horizontal.lengthSqr() < 1.0E-8D || horizontal.lengthSqr() > 16.0D
                    || forward.dot(horizontal.normalize()) < 0.65D) continue;
            nearby.hurt(server.damageSources().mobAttack(creeper), 4.0F);
            nearby.knockback(0.8D, -offset.x, -offset.z);
            if (nearby instanceof Player player) player.getCooldowns().addCooldown(Items.SHIELD, 100);
        }
        server.sendParticles(ParticleTypes.EXPLOSION, target.getX(), target.getY() + 0.5D, target.getZ(), 1, 0, 0, 0, 0);
        server.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY() + 0.5D, target.getZ(), 10, .3D, .3D, .3D, .08D);
        creeper.triggerCombatAnimation("horn_impact");
        cooldown = 100;
    }
}
