package com.carnis.mod.datagen;

import com.carnis.mod.CarnisMod;
import com.carnis.mod.init.ModBlocks;
import com.carnis.mod.init.ModItems;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.LanguageProvider;

public final class ModLanguageProvider extends LanguageProvider {
    private static final String EN_US = "en_us";
    private static final String RU_RU = "ru_ru";

    private final String locale;

    public ModLanguageProvider(PackOutput output, String locale) {
        super(output, CarnisMod.MOD_ID, locale);
        this.locale = locale;
    }

    @Override
    protected void addTranslations() {
        switch (locale) {
            case EN_US -> addEnglishTranslations();
            case RU_RU -> addRussianTranslations();
            default -> throw new IllegalStateException(
                    "Unsupported Carnis language provider locale: " + locale
            );
        }
    }

    private void addEnglishTranslations() {
        add("carnis.tab", "Carnis: Adaptive Hivemind");
        add("item.carnis.parasitic_tendril_spawn_egg", "Parasitic Tendril Spawn Egg");
        add("tooltip.carnis.parasitic_tendril_spawn_egg", "Spawns a parasitic tendril.");
        add("item.carnis.hive_sentinel_spawn_egg", "Hive Sentinel Spawn Egg");
        add("tooltip.carnis.hive_sentinel_spawn_egg", "Spawns a hive sentinel.");
        add("item.carnis.cerebral_nexus_spawn_egg", "Cerebral Nexus Spawn Egg");
        add("tooltip.carnis.cerebral_nexus_spawn_egg", "Spawns a cerebral nexus.");
        add("tooltip.carnis.biomass_remains", "Organic remains left by a host.");
        add("tooltip.carnis.flesh_bulb", "An incubating organic sac.");
        add("tooltip.carnis.sinew_spikes", "Piercing growths slow creatures.");
        add("tooltip.carnis.biomass_maggot_spawn_egg", "Spawns a biomass maggot.");
        add("codex.carnis.previous", "< Back");
        add("codex.carnis.next", "Next >");
        add("codex.carnis.tab.0", "Organogenesis");
        add("codex.carnis.tab.1", "Biocenosis");
        add("codex.carnis.tab.2", "Aberrations");
        add("codex.carnis.tab.3", "Biotechnology");
        add("codex.carnis.entry.0.title", "Pulsing Heart");
        add("codex.carnis.entry.0.body", "The colony core pulses every 100 ticks. Known flesh and veins measure growth within 32 blocks; the pulse itself reaches 8.");
        add("codex.carnis.entry.0.note", "The heart counts only tissue it has discovered.");
        add("codex.carnis.entry.1.title", "Order of organs");
        add("codex.carnis.entry.1.body", "At 25, 50, 75 and 100 infected blocks the Hive develops an eye, sentinel, pool and pillar. Growth requires living flesh 8–24 blocks away.");
        add("codex.carnis.entry.1.note", "Organs grow where the cell finds a suitable place.");
        add("codex.carnis.entry.2.title", "Hive Eye");
        add("codex.carnis.entry.2.body", "The sensor detects outsiders within 18 blocks and alerts free Hive mobs within 28 blocks.");
        add("codex.carnis.entry.2.note", "The scream is heard before the pupil is seen.");
        add("codex.carnis.entry.3.title", "Stomach Pool");
        add("codex.carnis.entry.3.body", "Acid dissolves items and living tissue. Livestock killed within it yields 20 biomass to a nearby heart, or 30 for a cow.");
        add("codex.carnis.entry.3.note", "Five damage per second is reason enough to stay out.");
        add("codex.carnis.entry.4.title", "Nerve Pillar");
        add("codex.carnis.entry.4.body", "The pillar blocks new thermal shock within 32 blocks. Its shield reduces ignition of Hive forms but does not make flesh fireproof.");
        add("codex.carnis.entry.4.note", "Destroy the anchor first. Then cleanse the site.");
        add("codex.carnis.entry.5.title", "Sentinel and Nexus");
        add("codex.carnis.entry.5.body", "A psychic anchor draws livestock into a trance and guides it to a pool. With four organs and 200 biomass the heart can become a Cerebral Nexus.");
        add("codex.carnis.entry.5.note", "Two daughter hearts appear on known flesh 48–64 blocks away.");
        add("codex.carnis.entry.6.title", "Biomass Remains");
        add("codex.carnis.entry.6.body", "A host dying on solid ground leaves loose remains. They slow outsiders and Hive creatures alike; maggots appear near carrion.");
        add("codex.carnis.entry.6.note", "No sample was obtained in water or without support.");
        add("codex.carnis.entry.7.title", "Biomass Maggot");
        add("codex.carnis.entry.7.body", "The maggot seeks remains within 16 blocks. Two meals awaken its burrowing instinct; one minute on flesh is enough.");
        add("codex.carnis.entry.7.note", "It chooses loose soil or flesh, not stone.");
        add("codex.carnis.entry.8.title", "Maturing Cocoon");
        add("codex.carnis.entry.8.body", "The Flesh Bulb attaches to ceilings or floors. After 60–90 seconds its heartbeat quickens and the sac bursts, releasing tendrils.");
        add("codex.carnis.entry.8.note", "Time passes only in loaded areas.");
        add("codex.carnis.entry.9.title", "Tendril: implantation");
        add("codex.carnis.entry.9.body", "Contact infects a peaceful host with 85% probability or a monster with 45%; armor reduces the monster chance to 30%. The parasite vanishes after its attempt.");
        add("codex.carnis.entry.9.note", "Failure brings a hiss and a minor wound.");
        add("codex.carnis.entry.10.title", "Four stages");
        add("codex.carnis.entry.10.body", "Up to 10 seconds: incubation; up to 25: veins and growths; up to 30: rupture and soil infection. Then a monster mutates and a peaceful host decomposes.");
        add("codex.carnis.entry.10.note", "In the third stage the wound can kill before transformation.");
        add("codex.carnis.entry.11.title", "Infected Zombie");
        add("codex.carnis.entry.11.body", "Its right arm has grown into a bone blade; tendrils frame its torn head. Near remains it stops and consumes biomass.");
        add("codex.carnis.entry.11.note", "While feeding, its gaze holds one direction.");
        add("codex.carnis.entry.12.title", "Infected Skeleton");
        add("codex.carnis.entry.12.body", "A bone scythe replaces its weapon. A sprouting nerve and ribcage core glow red; a sweep can strike nearby targets.");
        add("codex.carnis.entry.12.note", "An empty eye socket does not mean it cannot see.");
        add("codex.carnis.entry.13.title", "Infected Creeper");
        add("codex.carnis.entry.13.body", "Swollen sacs shudder before rupture. Instead of a normal explosion it releases spores, poisons living creatures and leaves veins on solid faces.");
        add("codex.carnis.entry.13.note", "Frantic antennae signal imminent detonation.");
        add("codex.carnis.entry.14.title", "Flesh Amalgam");
        add("codex.carnis.entry.14.body", "A titanic symbiote forms when infected creatures fuse near a heart. Bone plates and acid change with Hive adaptation.");
        add("codex.carnis.entry.14.note", "A weakened Amalgam consumes remains and lesser forms; beware its shockwave and corrosive bile.");
        add("codex.carnis.entry.15.title", "Pneumatic Inoculator");
        add("codex.carnis.entry.15.body", "A dart carries a viral strain or a purifying compound. Account for projectile drop and cover; firing consumes a suitable carried dart.");
        add("codex.carnis.entry.15.note", "The purifying compound reduces player infection by 35.");
        add("codex.carnis.entry.16.title", "Bio-Purifier");
        add("codex.carnis.entry.16.body", "A stream of fire sterilizes living and ossified flesh, leaving charred tissue. Thermal shock usually affects the infected area.");
        add("codex.carnis.entry.16.note", "An active nerve pillar blocks new thermal shock.");
        add("codex.carnis.entry.17.title", "Neuro armor");
        add("codex.carnis.entry.17.body", "Woven tendons connect the armor to the wearer’s nervous system. Each protected piece reduces infectious exposure by a quarter.");
        add("codex.carnis.entry.17.note", "A full set hides its wearer from the Eye, but does not promise invisibility to all.");
        add(ModItems.PURIFICATION_SERUM.get(), "Purification Serum");
        add(ModItems.BIO_PURIFIER.get(), "Bio-Purifier");
        add(
                ModItems.NEURO_RESONATOR_HELMET.get(),
                "Neuro-Resonator Helmet"
        );
        add(
                "death.attack.bio_purifier",
                "%1$s was incinerated by a bio-purifier"
        );
        add(
                "death.attack.bio_purifier.player",
                "%1$s was incinerated by %2$s's bio-purifier"
        );


        // Remaining custom damage message IDs from the registered damage types.
        add("death.attack.carnis_tainted_sludge", "%1$s dissolved in tainted sludge");
        add("death.attack.necrotic_consumption", "%1$s was consumed by the hivemind");
        add("death.attack.organic_consumption", "%1$s was consumed by the hive");
        add("death.attack.purification_dart", "%1$s was purified by a dart");
        add("death.attack.purification_dart.player", "%1$s was purified by %2$s");

        // Complete shared subtitle bank and custom damage death messages.
        add("carnis.subtitle.pustule_burst", "Pustule bursts");
        add("carnis.subtitle.hive_eye_screech", "Hive eye screeches");
        add("carnis.subtitle.hive_alarm", "Hive alarm");
        add("carnis.subtitle.acid_splash", "Acid splashes");
        add("carnis.subtitle.amalgamation_fuse", "Amalgamation begins");
        add("carnis.subtitle.digestor_churn", "Digestor churns");
        add("carnis.subtitle.flesh_amalgam_ambient", "Flesh amalgam groans");
        add("carnis.subtitle.flesh_amalgam_death", "Flesh amalgam dies");
        add("carnis.subtitle.flesh_amalgam_hurt", "Flesh amalgam hurt");
        add("carnis.subtitle.phantom_creeper", "Phantom creeper hisses");
        add("carnis.subtitle.phantom_whisper", "A phantom whispers");
        add("carnis.subtitle.synapse_rupture", "Synapse ruptures");
        add("carnis.subtitle.heartbeat_loop", "Heartbeat");
        add("carnis.subtitle.amalgam_roar", "Amalgam roars");
        add("carnis.subtitle.flamethrower_fire", "Flamethrower fires");
        add("carnis.subtitle.synapse_shock", "Synapse shocks");
        add("carnis.subtitle.pulsing_heart_beat", "Pulsing heart beats");
        add("carnis.subtitle.inoculator_fire", "Inoculator fires");
        add("carnis.subtitle.dart_hit", "Dart hits");
        add("carnis.subtitle.purifier_ignite", "Purifier ignites");
        add("carnis.subtitle.purifier_loop", "Purifier runs");
        add("carnis.subtitle.amalgam_smash", "Amalgam smashes");
        add("carnis.subtitle.creeper_rupture", "Creeper ruptures");
        add("carnis.subtitle.organic_creak", "Organic mass creaks");
        add("carnis.subtitle.hive_heartbeat", "The Hive heartbeat");
        add("carnis.subtitle.amalgam_step", "Heavy amalgam step");
        add("carnis.subtitle.phantom_footsteps", "Phantom footsteps");
        add("carnis.subtitle.hive_ambient", "The Hive breathes");
        add("carnis.subtitle.hive_ambient_close", "The Hive stirs nearby");
        add("carnis.subtitle.hive_pulse", "The Hive pulses");
        add("carnis.subtitle.hive_ambient_tonal_stinger", "A Hive tone rings out");
        add("carnis.subtitle.flesh_block_step", "Footsteps squelch through flesh");
        add("carnis.subtitle.hive_block_place", "Hive tissue grows");
        add("carnis.subtitle.hive_block_break", "Hive tissue tears");
        add("carnis.subtitle.hive_spread", "The Hive spreads");
        add("carnis.subtitle.combat_flesh_hit", "Flesh is struck");
        add("carnis.subtitle.combat_flesh_hit_deep", "A deep blow lands");
        add("carnis.subtitle.combat_dismember", "A body part is severed");
        add("carnis.subtitle.hive_detail_flow", "Fluid flows through the Hive");
        add("carnis.subtitle.hive_detail_membrane", "A membrane flexes");
        add("carnis.subtitle.hive_detail_bubbles", "Bubbles rise in the Hive");
        add("carnis.subtitle.hive_detail_creak", "Organic tissue creaks");
        add("carnis.subtitle.hive_detail_scuttle", "Something scuttles within the Hive");
        add("carnis.subtitle.hive_spawn_alert", "A Hive creature alerts");
        add("carnis.subtitle.hive_spawn_attack", "A Hive creature attacks");
        add("carnis.subtitle.hive_spawn_idle", "A Hive creature stirs");
        add("carnis.subtitle.hive_spawn_hurt", "A Hive creature is hurt");
        add("carnis.subtitle.hive_spawn_hurt_critical", "A Hive creature suffers a critical wound");
        add("carnis.subtitle.hive_spawn_skeleton_whip", "Infected Skeleton lashes");
        add("carnis.subtitle.hive_spawn_skeleton_blade", "Infected Skeleton strikes");
        add("carnis.subtitle.hive_spawn_skeleton_bonecrack", "Bones crack");
        add("carnis.subtitle.hive_spawn_death", "A Hive creature dies");
        add("carnis.subtitle.bone_deflect", "Bone deflects the blow");
        add("carnis.subtitle.combat_armor_deflect", "Armor deflects the blow");
        add("carnis.subtitle.combat_block_stab", "A weapon strikes the shield");
        add("carnis.subtitle.amb_hive_surface", "Hive hums (surface)");
        add("carnis.subtitle.amb_hive_deep", "Hive groans (deep)");
        add("carnis.subtitle.amb_hive_core", "Hive pulses (core)");
        add("carnis.subtitle.amb_hive_threshold", "Hive breathes (threshold)");
        add("carnis.subtitle.zone_stinger_intensify", "Hive membrane tightens");
        add("carnis.subtitle.zone_stinger_release", "Hive membrane relaxes");
        add("carnis.subtitle.zone_stinger_deep", "Descending into the hive");
        add("carnis.subtitle.hive_spawn_creeper_sac", "An infected creeper sac pulses");
        add("carnis.subtitle.hive_spawn_creeper_crawl", "An infected creeper crawls");
        add("carnis.subtitle.hive_spawn_creeper_detonate", "An infected creeper detonates");
        add("carnis.subtitle.hive_amalgam_shuffle", "The amalgam shuffles");
        add("carnis.subtitle.hive_amalgam_breath", "The amalgam breathes");
        add("carnis.subtitle.hive_amalgam_slam", "The amalgam slams down");
        add("death.attack.organic_consumption.player", "%1$s was consumed by %2$s");
        add("death.attack.bio_purifier_surface", "%1$s was burned by bio-purifier residue");
        add("death.attack.bio_purifier_surface.player", "%1$s was burned by %2$s's bio-purifier residue");
        add("death.attack.necrotic_consumption.player", "%1$s was consumed by %2$s's necrotic touch");
        add("death.attack.tainted_sludge", "%1$s dissolved in tainted sludge");
        add("death.attack.tainted_sludge.player", "%1$s was pushed into tainted sludge by %2$s");
        add("death.attack.carnis_tainted_sludge.player", "%1$s was dissolved in tainted sludge by %2$s");

    }

    private void addRussianTranslations() {
        add("carnis.tab", "Carnis: Адаптивный коллективный разум");
        add("item.carnis.parasitic_tendril_spawn_egg", "Яйцо призыва: Паразитическое щупальце");
        add("tooltip.carnis.parasitic_tendril_spawn_egg", "Призывает существо: Паразитическое щупальце.");
        add("item.carnis.hive_sentinel_spawn_egg", "Яйцо призыва: Страж Улья");
        add("tooltip.carnis.hive_sentinel_spawn_egg", "Призывает существо: Страж Улья.");
        add("item.carnis.cerebral_nexus_spawn_egg", "Яйцо призыва: Мозговой Нексус");
        add("tooltip.carnis.cerebral_nexus_spawn_egg", "Призывает существо: Мозговой Нексус.");
        add("tooltip.carnis.biomass_remains", "Органические останки хозяина.");
        add("tooltip.carnis.flesh_bulb", "Созревающий органический мешок.");
        add("tooltip.carnis.sinew_spikes", "Колючие наросты замедляют существ.");
        add("tooltip.carnis.biomass_maggot_spawn_egg", "Призывает личинку биомассы.");
        add("codex.carnis.previous", "< Назад");
        add("codex.carnis.next", "Вперёд >");
        add("codex.carnis.tab.0", "Органогенез");
        add("codex.carnis.tab.1", "Биоценоз");
        add("codex.carnis.tab.2", "Аберрации");
        add("codex.carnis.tab.3", "Биотехнологии");
        add("codex.carnis.entry.0.title", "Пульсирующее сердце");
        add("codex.carnis.entry.0.body", "Центр колонии пульсирует каждые 100 тиков. Известная ему плоть и жилы дают меру роста в радиусе 32 блоков; сам импульс охватывает 8.");
        add("codex.carnis.entry.0.note", "Сердце считает лишь обнаруженную ткань.");
        add("codex.carnis.entry.1.title", "Порядок органов");
        add("codex.carnis.entry.1.body", "На 25, 50, 75 и 100 заражённых блоках улей закладывает око, стража, бассейн и столп. Для роста требуется живая плоть в 8–24 блоках.");
        add("codex.carnis.entry.1.note", "Орган растёт там, где клетка считает место пригодным.");
        add("codex.carnis.entry.2.title", "Око Улья");
        add("codex.carnis.entry.2.body", "Сенсор замечает чужаков в пределах 18 блоков и передаёт тревогу свободным мобам Улья в радиусе 28 блоков.");
        add("codex.carnis.entry.2.note", "Вопль слышен раньше, чем видно зрачок.");
        add("codex.carnis.entry.3.title", "Желудочный бассейн");
        add("codex.carnis.entry.3.body", "Кислота разлагает предметы и живую ткань. Погибший в ней скот отдаёт ближайшему сердцу 20 единиц биомассы, корова — 30.");
        add("codex.carnis.entry.3.note", "Пять единиц урона в секунду — достаточно, чтобы не входить.");
        add("codex.carnis.entry.4.title", "Нервный столп");
        add("codex.carnis.entry.4.body", "Столп рассеивает новый термический шок в радиусе 32 блоков. Щит сокращает поджог форм Улья, но не делает плоть несгораемой.");
        add("codex.carnis.entry.4.note", "Сначала разрушить якорь. Затем очистить очаг.");
        add("codex.carnis.entry.5.title", "Страж и Нексус");
        add("codex.carnis.entry.5.body", "Пси-якорь вводит скот в транс и ведёт его к бассейну. При четырёх органах и 200 единицах сердце может стать Мозговым Нексусом.");
        add("codex.carnis.entry.5.note", "Два дочерних сердца возникают на известной плоти в 48–64 блоках.");
        add("codex.carnis.entry.6.title", "Остатки биомассы");
        add("codex.carnis.entry.6.body", "На твёрдом полу гибель хозяина оставляет рыхлые останки. Они замедляют и чужаков, и существ Улья; близ падали появляются личинки.");
        add("codex.carnis.entry.6.note", "В воде и без опоры образец получить не удалось.");
        add("codex.carnis.entry.7.title", "Личинка биомассы");
        add("codex.carnis.entry.7.body", "Личинка ищет останки в радиусе 16 блоков. Два приёма пищи пробуждают инстинкт зарывания; час на плоти не требуется — достаточно минуты.");
        add("codex.carnis.entry.7.note", "Она выбирает рыхлую землю или плоть, но не камень.");
        add("codex.carnis.entry.8.title", "Кокон созревания");
        add("codex.carnis.entry.8.body", "Мясная луковица держится на потолке или на полу. Через 60–90 секунд её сердцебиение учащается, мешок лопается и выпускает щупальца.");
        add("codex.carnis.entry.8.note", "Счёт идёт только в загруженной области.");
        add("codex.carnis.entry.9.title", "Щупальце: внедрение");
        add("codex.carnis.entry.9.body", "При контакте вероятность заражения мирного хозяина — 85%, монстра — 45%; броня снижает шанс монстра до 30%. Паразит исчезает после броска.");
        add("codex.carnis.entry.9.note", "Провал сопровождается шипением и слабым ранением.");
        add("codex.carnis.entry.10.title", "Четыре стадии");
        add("codex.carnis.entry.10.body", "До 10 секунд — инкубация; до 25 — вены и опухоли; до 30 — разрыв и заражение почвы. Затем монстр мутирует, а мирный хозяин разлагается.");
        add("codex.carnis.entry.10.note", "На третьей стадии рана способна убить до превращения.");
        add("codex.carnis.entry.11.title", "Заражённый зомби");
        add("codex.carnis.entry.11.body", "Правая рука разрослась в костяной клинок; жгутики обрамляют разорванную голову. У останков он замирает и поглощает биомассу.");
        add("codex.carnis.entry.11.note", "Во время питания его взгляд удерживается на одном направлении.");
        add("codex.carnis.entry.12.title", "Заражённый скелет");
        add("codex.carnis.entry.12.body", "Костяной серп заменяет оружие. Проросший нерв и ядро в рёбрах излучают красный свет; удар лезвием может задеть соседние цели.");
        add("codex.carnis.entry.12.note", "Не принимать пустую глазницу за отсутствие зрения.");
        add("codex.carnis.entry.13.title", "Заражённый крипер");
        add("codex.carnis.entry.13.body", "Раздутые мешки колышутся до разрыва. Вместо обычного взрыва он выбрасывает споры, травит живых и оставляет жилы на прочных гранях.");
        add("codex.carnis.entry.13.note", "Признак детонации — бешеное дрожание нервных усиков.");
        add("codex.carnis.entry.14.title", "Амальгама плоти");
        add("codex.carnis.entry.14.body", "Титанический симбиот возникает из слияния заражённых форм у сердца. Костяные пластины и кислота меняются вместе с адаптацией Улья.");
        add("codex.carnis.entry.14.note", "Ослабленная амальгама поглощает останки и малые формы; берегитесь ударной волны и едкой желчи.");
        add("codex.carnis.entry.15.title", "Пневмоинокулятор");
        add("codex.carnis.entry.15.body", "Дротик несёт вирусный штамм или очищающий состав. На расстоянии учитывайте падение снаряда и укрытия; магазин расходует подходящие дротики.");
        add("codex.carnis.entry.15.note", "Очищающий состав снижает заражение игрока на 35.");
        add("codex.carnis.entry.16.title", "Био-очиститель");
        add("codex.carnis.entry.16.body", "Поток огня стерилизует живую и окостеневшую плоть, оставляя обугленную ткань. Термический удар обычно вызывает шок заражённого участка.");
        add("codex.carnis.entry.16.note", "Действующий нервный столп блокирует новый термошок.");
        add("codex.carnis.entry.17.title", "Нейро-броня");
        add("codex.carnis.entry.17.body", "Вплетённые сухожилия связывают доспех с нервной системой носителя. Каждая защищённая часть уменьшает заражающую экспозицию на четверть.");
        add("codex.carnis.entry.17.note", "Полный комплект скрывает носителя от Ока, но не обещает невидимости всем.");
        add("entity.carnis.hive_sentinel", "Страж Улья");
        add("entity.carnis.cerebral_nexus", "Мозговой узел");
        add(ModItems.PURIFICATION_SERUM.get(), "Очищающая сыворотка");
        add(ModItems.BIO_PURIFIER.get(), "Очищающий огнемёт");
        add(
                ModItems.NEURO_RESONATOR_HELMET.get(),
                "Нейро-резонаторный шлем"
        );
        add(
                "death.attack.bio_purifier",
                "%1$s сожжён биоочистителем"
        );
        add(
                "death.attack.bio_purifier.player",
                "%1$s сожжён биоочистителем игрока %2$s"
        );


        // Remaining custom damage message IDs from the registered damage types.
        add("death.attack.carnis_tainted_sludge", "%1$s растворился в заражённой жиже");
        add("death.attack.necrotic_consumption", "%1$s поглощён коллективным разумом");
        add("death.attack.organic_consumption", "%1$s был поглощён Ульем");
        add("death.attack.purification_dart", "%1$s очищен дротиком");
        add("death.attack.purification_dart.player", "%1$s очищен игроком %2$s");

        // Complete shared subtitle bank and custom damage death messages.
        add("carnis.subtitle.pustule_burst", "Пустула лопнула");
        add("carnis.subtitle.hive_eye_screech", "Улей-глаз визжит");
        add("carnis.subtitle.hive_alarm", "Тревога улья");
        add("carnis.subtitle.acid_splash", "Кислота шипит");
        add("carnis.subtitle.amalgamation_fuse", "Слияние начинается");
        add("carnis.subtitle.digestor_churn", "Перевариватель урчит");
        add("carnis.subtitle.flesh_amalgam_ambient", "Плотский амальгам стонет");
        add("carnis.subtitle.flesh_amalgam_death", "Плотский амальгам погибает");
        add("carnis.subtitle.flesh_amalgam_hurt", "Плотский амальгам ранен");
        add("carnis.subtitle.phantom_creeper", "Фантомный крипер шипит");
        add("carnis.subtitle.phantom_whisper", "Фантом шепчет");
        add("carnis.subtitle.synapse_rupture", "Синапс разрывается");
        add("carnis.subtitle.heartbeat_loop", "Сердцебиение");
        add("carnis.subtitle.amalgam_roar", "Амальгам рычит");
        add("carnis.subtitle.flamethrower_fire", "Огнемёт стреляет");
        add("carnis.subtitle.synapse_shock", "Разряд синапса");
        add("carnis.subtitle.pulsing_heart_beat", "Пульсирующее сердце бьётся");
        add("carnis.subtitle.inoculator_fire", "Инокулятор стреляет");
        add("carnis.subtitle.dart_hit", "Дротик попал");
        add("carnis.subtitle.purifier_ignite", "Очиститель зажёгся");
        add("carnis.subtitle.purifier_loop", "Очиститель работает");
        add("carnis.subtitle.amalgam_smash", "Амальгам бьёт");
        add("carnis.subtitle.creeper_rupture", "Крипер разрывается");
        add("carnis.subtitle.organic_creak", "Органическая масса скрипит");
        add("carnis.subtitle.hive_heartbeat", "Сердцебиение Улья");
        add("carnis.subtitle.amalgam_step", "Тяжёлый шаг амальгамы");
        add("carnis.subtitle.phantom_footsteps", "Призрачные шаги");
        add("carnis.subtitle.hive_ambient", "Улей дышит");
        add("carnis.subtitle.hive_ambient_close", "Улей шевелится рядом");
        add("carnis.subtitle.hive_pulse", "Улей пульсирует");
        add("carnis.subtitle.hive_ambient_tonal_stinger", "Звучит тон Улья");
        add("carnis.subtitle.flesh_block_step", "Шаги хлюпают по плоти");
        add("carnis.subtitle.hive_block_place", "Ткань Улья разрастается");
        add("carnis.subtitle.hive_block_break", "Ткань Улья разрывается");
        add("carnis.subtitle.hive_spread", "Улей распространяется");
        add("carnis.subtitle.combat_flesh_hit", "Удар по плоти");
        add("carnis.subtitle.combat_flesh_hit_deep", "Тяжёлый удар");
        add("carnis.subtitle.combat_dismember", "Часть тела отсечена");
        add("carnis.subtitle.hive_detail_flow", "Жидкость течёт внутри Улья");
        add("carnis.subtitle.hive_detail_membrane", "Мембрана натягивается");
        add("carnis.subtitle.hive_detail_bubbles", "В Улье поднимаются пузыри");
        add("carnis.subtitle.hive_detail_creak", "Органическая ткань скрипит");
        add("carnis.subtitle.hive_detail_scuttle", "В Улье кто-то шуршит");
        add("carnis.subtitle.hive_spawn_alert", "Существо Улья подаёт сигнал");
        add("carnis.subtitle.hive_spawn_attack", "Существо Улья атакует");
        add("carnis.subtitle.hive_spawn_idle", "Существо Улья шевелится");
        add("carnis.subtitle.hive_spawn_hurt", "Существо Улья ранено");
        add("carnis.subtitle.hive_spawn_hurt_critical", "Существо Улья получает критическое ранение");
        add("carnis.subtitle.hive_spawn_skeleton_whip", "Заражённый скелет щёлкает жгутиком");
        add("carnis.subtitle.hive_spawn_skeleton_blade", "Заражённый скелет бьёт клинком");
        add("carnis.subtitle.hive_spawn_skeleton_bonecrack", "Кости хрустят");
        add("carnis.subtitle.hive_spawn_death", "Существо Улья погибает");
        add("carnis.subtitle.bone_deflect", "Кость отражает удар");
        add("carnis.subtitle.combat_armor_deflect", "Броня отражает удар");
        add("carnis.subtitle.combat_block_stab", "Оружие ударяет по щиту");
        add("carnis.subtitle.amb_hive_surface", "Улей гудит (поверхность)");
        add("carnis.subtitle.amb_hive_deep", "Улей стонет (глубина)");
        add("carnis.subtitle.amb_hive_core", "Улей пульсирует (ядро)");
        add("carnis.subtitle.amb_hive_threshold", "Улей дышит (порог)");
        add("carnis.subtitle.zone_stinger_intensify", "Мембрана улья натягивается");
        add("carnis.subtitle.zone_stinger_release", "Мембрана улья ослабевает");
        add("carnis.subtitle.zone_stinger_deep", "Погружение в улей");
        add("carnis.subtitle.hive_spawn_creeper_sac", "Мешок заражённого крипера пульсирует");
        add("carnis.subtitle.hive_spawn_creeper_crawl", "Заражённый крипер ползёт");
        add("carnis.subtitle.hive_spawn_creeper_detonate", "Заражённый крипер взрывается");
        add("carnis.subtitle.hive_amalgam_shuffle", "Амальгам шаркает");
        add("carnis.subtitle.hive_amalgam_breath", "Амальгам дышит");
        add("carnis.subtitle.hive_amalgam_slam", "Амальгам обрушивает удар");
        add("death.attack.organic_consumption.player", "%1$s был поглощён %2$s");
        add("death.attack.bio_purifier_surface", "%1$s сожжён остатками биоочистителя");
        add("death.attack.bio_purifier_surface.player", "%1$s сожжён остатками биоочистителя %2$s");
        add("death.attack.necrotic_consumption.player", "%1$s поглощён некротическим прикосновением %2$s");
        add("death.attack.tainted_sludge", "%1$s растворился в заражённой жиже");
        add("death.attack.tainted_sludge.player", "%1$s столкнут в заражённую жижу игроком %2$s");
        add("death.attack.carnis_tainted_sludge.player", "%1$s растворился в заражённой жиже из-за %2$s");

    }
}
