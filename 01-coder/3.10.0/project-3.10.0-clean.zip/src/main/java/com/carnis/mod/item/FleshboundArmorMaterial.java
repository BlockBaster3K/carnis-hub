package com.carnis.mod.item;

import com.carnis.mod.init.ModItems;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * Плотевой материал брони (задача броня 3.10.0).
 *
 * <p>Второй материал мода после {@code NEURO_RESONATOR}. Играется как «сырая»
 * плоть: меньше прочности, чем нейро-резонатор, зато выше стойкость к удару.
 * Ремонтируется живой плотью, как и нейро-резонатор. Сет из четырёх частей
 * дарует проход сквозь тело улья — см. {@code FleshboundArmorItem#isFullSet}.
 */
public enum FleshboundArmorMaterial implements ArmorMaterial {
    INSTANCE;

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> 275;
            case CHESTPLATE -> 400;
            case LEGGINGS -> 375;
            case BOOTS -> 325;
        };
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> 3;
            case CHESTPLATE -> 8;
            case LEGGINGS -> 6;
            case BOOTS -> 2;
        };
    }

    @Override public int getEnchantmentValue() { return 10; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_LEATHER; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.LIVING_FLESH.get()); }
    @Override public String getName() { return "carnis:fleshbound"; }
    @Override public float getToughness() { return 2.0F; }
    @Override public float getKnockbackResistance() { return 0.10F; }
}
