# 3.5.0 → целевая 3.5.1 — horror items p3: четыре PNG

## Статус
Партия на рассмотрение Ревизора; художественный вердикт не заявлен. Рабочая копия 3.4.10 не изменена. Модели и код не входят в пакет.

## Источник
Исходные PNG и модели взяты из `01-coder/3.5.0/project-3.5.0-clean.zip`, commit `faf461eefe057143cd8cd446a84f72d143d78139`; SHA-256 архива `11833ab250a815fa85c01eb2bef68ef544440e857cf43ccd8ba3a46a789f3ec5` совпал с `SHA256SUMS.txt` в том же commit. Целевой проект 3.5.1 в этом архиве не представлен; совпадение его ресурсов с baseline 3.5.0 не проверено.

| PNG | Размер | Байт | SHA-256 |
|---|---:|---:|---|
| `textures/item/purification_serum.png` | 64×64 RGBA | 4785 | `5c3b19b85affd4e98e84c3e2c5ea1b5f4064d592cc10e8d357131c6ac82ac957` |
| `textures/item/purification_vial.png` | 64×64 RGBA | 3423 | `73cbea3e7c355c968dc7978468eb0623686bb2e415ff45f8fd3dffca22ac514a` |
| `textures/item/pustule_grenade.png` | 64×64 RGBA | 6008 | `2715085d47c1bd1e85e0512dbfa0195952d92c7cae654692617a49d887e02e5b` |
| `textures/item/tainted_sludge_bucket.png` | 64×64 RGBA | 4217 | `9ece15520b85c523bb8d8ced3c11346028e9bd20a0ad387b2ea6d428a0be581b` |

## Для Интегратора
- PNG в архиве расположены как `assets/carnis/textures/item/*.png` (путь ресурса); перед переносом сверить хеши исходников и моделей с `manifest.json` в целевой версии.
- В clean 3.5.0 исходный `purification_serum.png` находится в **`src/generated/resources/assets/carnis/textures/item/`**, а три остальных PNG — в `src/main/resources/assets/carnis/textures/item/`. Путь каждого исходного файла записан в manifest. `src/generated/resources` включён в resource source set; не класть копии в оба дерева без проверки приоритета/дубликатов. Возможное перегенерирование serum — проверить в целевой сборке; 3.5.1 не исследован.
- Все оригиналы 16×16; новые 64×64. Модели указаны в manifest, без изменений. Исходники для проверки сохранены в `analysis_horror_350/selected_baseline/`.

## Проверки и ограничения
- Preview показывает 64px на двух фонах и приближённую имитацию 16px; ведро перерисовано с более заметной ручкой.
- Порогово проверены прозрачные границы, цветовой spill и компоненты; это не заменяет художественную оценку и тест Minecraft. В игре и на целевой версии 3.5.1 не проверялось.
- LOCK: 9/9 в локальной рабочей копии 3.4.10 после подготовки совпадают с baseline; защищённые пути в пакете отсутствуют. LOCK целевой 3.5.1 не проверялся.

## Следующая очередь
p4: `bone_scythe.png`, `ossified_scythe.png`, `sinew_shield.png`; до сдачи исследовать назначение UV и фактические модели, без изменений geo/кода. `creeping_tendrils.png` — вместе с существами. Четыре старых файла `bio_purifier.png`, `bio_purifier_geo.png`, `bio_purifier_glowmask.png`, `pneumatic_inoculator_geo.png` выведены из текущей очереди по указанию координатора; статус их художественного соответствия не подтверждён.

Мои прежние «шесть» считались по одному файлу: `tainted_sludge_bucket.png`, `creeping_tendrils.png` и четыре файла purifier/inoculator, а не тремя атласами одной позицией. Новые serum/vial/grenade и три файла p4 отсутствуют в исходной 3.4.10 и относятся к расширенной очереди 3.5.0/3.5.1.
