package com.carnis.mod.entity;

import com.carnis.mod.entity.ai.CarnisFeedingGoal;
import com.carnis.mod.entity.ai.CarnisGestationGoal;
import com.carnis.mod.entity.ai.HiveDefendHeartGoal;
import com.carnis.mod.entity.ai.HiveEscortLeaderGoal;
import com.carnis.mod.entity.ai.HiveSwarmCoordinator;
import com.carnis.mod.init.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public final class InfectedSkeletonEntity extends HiveEntity implements HivemindLinkedMob, AssimilatingMob, GeoEntity {
    private static final long BIOMASS_VALUE = 5L;
    private static final int WHIP_ANIMATION_TICKS = 9;
    private static final EntityDataAccessor<Integer> COMBAT_VARIANT =
            SynchedEntityData.defineId(InfectedSkeletonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> ASSIMILATING =
            SynchedEntityData.defineId(InfectedSkeletonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> WHIP_ANIM_TICKS =
            SynchedEntityData.defineId(InfectedSkeletonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> BONE_RATTLE_ACTIVE =
            SynchedEntityData.defineId(InfectedSkeletonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.infected_skeleton.idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.infected_skeleton.walk");
    private static final RawAnimation ASSIMILATE = RawAnimation.begin().thenLoop("animation.infected_skeleton.assimilate");
    private static final RawAnimation BONE_RATTLE = RawAnimation.begin().thenLoop("animation.infected_skeleton.bone_rattle");
    private static final RawAnimation BLADE_ATTACK = RawAnimation.begin().thenPlay("animation.infected_skeleton.attack_scythe");
    private static final RawAnimation WHIP_ATTACK = RawAnimation.begin().thenPlay("animation.infected_skeleton.attack_whip");
    private static final RawAnimation HURT = RawAnimation.begin().thenPlay("animation.infected_skeleton.hurt");
    private static final RawAnimation DEATH = RawAnimation.begin().thenPlay("animation.infected_skeleton.death");
    private static final RawAnimation B_IDLE = RawAnimation.begin().thenLoop("animation.infected_skeleton_b.idle");
    private static final RawAnimation B_WALK = RawAnimation.begin().thenLoop("animation.infected_skeleton_b.walk");
    private static final RawAnimation B_ASSIMILATE = RawAnimation.begin().thenLoop("animation.infected_skeleton_b.assimilate");
    private static final RawAnimation B_HURT = RawAnimation.begin().thenPlay("animation.infected_skeleton_b.hurt");
    private static final RawAnimation B_DEATH = RawAnimation.begin().thenPlay("animation.infected_skeleton_b.death");
    private static final RawAnimation PIKE_THRUST = RawAnimation.begin().thenPlay("animation.infected_skeleton_b.attack_thrust");
    private static final RawAnimation SNIPER_SHOT = RawAnimation.begin().thenPlay("animation.infected_skeleton.sniper_shot");
    private static final int BONE_RATTLE_DURATION_TICKS = 40;
    private int idleTicks;
    private int boneRattleTicks;
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    public InfectedSkeletonEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(COMBAT_VARIANT, InfectedVariant.A.id());
        entityData.define(ASSIMILATING, false);
        entityData.define(WHIP_ANIM_TICKS, 0);
        entityData.define(BONE_RATTLE_ACTIVE, false);
    }

    public InfectedVariant getCombatVariant() { return InfectedVariant.fromId(entityData.get(COMBAT_VARIANT)); }
    public boolean isVariantA() { return getCombatVariant() == InfectedVariant.A; }
    public void setCombatVariant(InfectedVariant variant) {
        entityData.set(COMBAT_VARIANT, variant.id());
        applyVariantAttributes(variant);
    }
    private void applyVariantAttributes(InfectedVariant variant) {
        VariantAttributes.apply(this, variant);
    }
    @Override
    public net.minecraft.world.entity.SpawnGroupData finalizeSpawn(
            net.minecraft.world.level.ServerLevelAccessor level, net.minecraft.world.DifficultyInstance difficulty,
            net.minecraft.world.entity.MobSpawnType spawnType, net.minecraft.world.entity.SpawnGroupData groupData,
            net.minecraft.nbt.CompoundTag tag) {
        net.minecraft.world.entity.SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData, tag);
        // Выбор варианта здесь, а не в конструкторе: entityData доступен
        // только после defineSynchedData(), иначе значение откатывается к A.
        if (tag == null || !tag.contains(InfectedVariant.NBT_KEY, net.minecraft.nbt.Tag.TAG_INT)) {
            setCombatVariant(InfectedVariant.random(random));
        }
        applyVariantAttributes(getCombatVariant());
        setHealth(getMaxHealth());
        return result;
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(InfectedVariant.NBT_KEY, getCombatVariant().id());
    }
    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains(InfectedVariant.NBT_KEY, net.minecraft.nbt.Tag.TAG_INT)) {
            setCombatVariant(InfectedVariant.fromId(tag.getInt(InfectedVariant.NBT_KEY)));
        } else {
            // /summon и прочие пути без NBT не проходят через finalizeSpawn,
            // поэтому вариант иначе навсегда остался бы A из defineSynchedData().
            setCombatVariant(InfectedVariant.random(random));
        }
    }

    public boolean isVariantB() { return getCombatVariant() == InfectedVariant.B; }

    /** Server-side GeckoLib trigger entry point used by variant-specific combat Goals. */
    public void triggerCombatAnimation(String key) {
        if (!level().isClientSide) triggerAnim("action", key);
    }

    @Override
    public boolean isAssimilating() {
        return entityData.get(ASSIMILATING);
    }

    @Override
    public void setAssimilating(boolean assimilating) {
        boolean changed = entityData.get(ASSIMILATING) != assimilating;
        entityData.set(ASSIMILATING, assimilating);
        if (changed && assimilating && !level().isClientSide) {
            triggerAnim("movement", "assimilate");
        }
    }

    public boolean isWhipping() {
        return entityData.get(WHIP_ANIM_TICKS) > 0;
    }

    public void beginWhipAnimation() {
        entityData.set(WHIP_ANIM_TICKS, WHIP_ANIMATION_TICKS);
    }

    private void cancelWhipAnimation() {
        entityData.set(WHIP_ANIM_TICKS, 0);
    }

    private boolean isBoneRattleActive() {
        return entityData.get(BONE_RATTLE_ACTIVE);
    }

    private void tickIdleBoneRattle() {
        boolean idle = getTarget() == null && !isAssimilating() && !swinging && !isWhipping()
                && getDeltaMovement().horizontalDistanceSqr() < 0.0025D;
        if (!idle) {
            idleTicks = 0;
            boneRattleTicks = 0;
            entityData.set(BONE_RATTLE_ACTIVE, false);
            return;
        }

        if (boneRattleTicks > 0) {
            boneRattleTicks--;
            if (boneRattleTicks == 0) entityData.set(BONE_RATTLE_ACTIVE, false);
            return;
        }

        idleTicks++;
        if (idleTicks > 200 && tickCount % 20 == 0 && random.nextFloat() < 0.05F) {
            boneRattleTicks = BONE_RATTLE_DURATION_TICKS;
            idleTicks = 0;
            entityData.set(BONE_RATTLE_ACTIVE, true);
            level().playSound(null, blockPosition(), ModSounds.HIVE_SPAWN_SKELETON_BONECRACK.get(),
                    SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    @Override
    public void tick() {
        if (!level().isClientSide) {
            int whipAnimTicks = entityData.get(WHIP_ANIM_TICKS);
            if (whipAnimTicks > 0) entityData.set(WHIP_ANIM_TICKS, whipAnimTicks - 1);
            tickIdleBoneRattle();
        }
        super.tick();
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        if (isVariantB() && source.getDirectEntity() instanceof net.minecraft.world.entity.projectile.Projectile projectile) {
            Vec3 incoming = projectile.position().subtract(position());
            Vec3 facing = getLookAngle();
            Vec3 incomingHorizontal = new Vec3(incoming.x, 0.0D, incoming.z);
            Vec3 facingHorizontal = new Vec3(facing.x, 0.0D, facing.z);
            if (incomingHorizontal.lengthSqr() > 1.0E-8D && facingHorizontal.lengthSqr() > 1.0E-8D
                    && incomingHorizontal.normalize().dot(facingHorizontal.normalize()) > 0.5D) amount *= 0.5F;
        }
        boolean damaged = super.hurt(source, amount);
        if (damaged && isAlive() && !level().isClientSide) triggerAnim("action", "hurt");
        return damaged;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.HIVE_SPAWN_HURT.get();
    }

    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        if (!level().isClientSide) {
            cancelWhipAnimation();
            entityData.set(BONE_RATTLE_ACTIVE, false);
            triggerAnim("action", "death");
            level().playSound(null, blockPosition(), ModSounds.HIVE_SPAWN_DEATH.get(),
                    SoundSource.HOSTILE, 1.0F, 1.0F);
        }
        super.die(source);
    }

    @Override
    protected SoundEvent getDeathSound() {
        // die() emits the explicit death sound once, alongside the GeckoLib death animation.
        return null;
    }

    @Override
    public long getBiomassValue() {
        return BIOMASS_VALUE;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 25.0D)
                .add(Attributes.ATTACK_DAMAGE, 3.5D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.FOLLOW_RANGE, 20.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.2D)
                .add(Attributes.ARMOR, 1.0D);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement", 2, state -> {
            if (isAssimilating()) return state.setAndContinue(isVariantB() ? B_ASSIMILATE : ASSIMILATE);
            if (state.isMoving()) {
                state.getController().setAnimationSpeed(WalkAnimationSync.factor(this));
                return state.setAndContinue(isVariantB() ? B_WALK : WALK);
            }
            if (isVariantB()) return state.setAndContinue(B_IDLE);
            return state.setAndContinue(isBoneRattleActive() ? BONE_RATTLE : IDLE);
        }).triggerableAnim("assimilate", isVariantB() ? B_ASSIMILATE : ASSIMILATE));
        controllers.add(new AnimationController<>(this, "action", 0, state -> {
            if (isWhipping()) return state.setAndContinue(WHIP_ATTACK);
            if (!isAssimilating() && swinging) return state.setAndContinue(isVariantB() ? PIKE_THRUST : BLADE_ATTACK);
            state.getController().forceAnimationReset();
            return PlayState.STOP;
        }).triggerableAnim("hurt", isVariantB() ? B_HURT : HURT)
                .triggerableAnim("death", isVariantB() ? B_DEATH : DEATH)
                .triggerableAnim("pike_thrust", PIKE_THRUST)
                .triggerableAnim("sniper_shot", isVariantB() ? PIKE_THRUST : SNIPER_SHOT));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new com.carnis.mod.entity.ai.InfectedSkeletonSniperGoal(this));
        goalSelector.addGoal(1, new InfectedSkeletonAttackGoal(this, 1.0D));
        goalSelector.addGoal(2, new MoveTowardsRestrictionGoal(this, 0.9D));
        goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 10.0F));
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        goalSelector.addGoal(6, new HiveDefendHeartGoal(this));
        goalSelector.addGoal(7, new HiveEscortLeaderGoal(this));
        goalSelector.addGoal(8, new CarnisFeedingGoal(this));
        goalSelector.addGoal(9, new CarnisGestationGoal(this));

        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 20, true, false,
                target -> HiveSwarmCoordinator.validTarget(this, target)));
        targetSelector.addGoal(2, new HurtByTargetGoal(this));
    }

    /** Immediate-hit checks are separate from target eligibility so out-of-range targets can be pursued. */
    private boolean canAttackNow(LivingEntity target) {
        if (!HiveSwarmCoordinator.validTarget(this, target)) return false;
        Vec3 offset = target.position().subtract(position());
        Vec3 horizontal = new Vec3(offset.x, 0.0D, offset.z);
        double meleeReach = isVariantB() ? 16.0D : 9.0D;
        if (offset.lengthSqr() > meleeReach || !hasLineOfSight(target)) return false;
        if (horizontal.lengthSqr() < 1.0E-8D) return true;

        Vec3 look = getLookAngle();
        Vec3 forward = new Vec3(look.x, 0.0D, look.z);
        if (forward.lengthSqr() < 1.0E-8D) {
            double yaw = Math.toRadians(getYRot());
            forward = new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
        } else {
            forward = forward.normalize();
        }
        return forward.dot(horizontal.normalize()) >= -0.15D;
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (target != null && !HiveSwarmCoordinator.validTarget(this, target)) return;
        super.setTarget(target);
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        if (!(target instanceof LivingEntity livingTarget) || !canAttackNow(livingTarget)) return false;
        boolean hit = super.doHurtTarget(target);
        if (hit && !level().isClientSide) {
            if (isVariantB()) triggerAnim("action", "pike_thrust");
            level().playSound(null, blockPosition(), ModSounds.HIVE_SPAWN_SKELETON_BLADE.get(),
                    SoundSource.HOSTILE, 1.0F, 1.0F);
        }
        return hit;
    }

    /** Resolve the wide 3-block lash; damage is lower than the close-range blade strike. */
    public void performWhipAttack() {
        if (!(level() instanceof ServerLevel server)) return;
        Vec3 look = getLookAngle();
        Vec3 forward = new Vec3(look.x, 0.0D, look.z);
        if (forward.lengthSqr() < 1.0E-8D) {
            double yaw = Math.toRadians(getYRot());
            forward = new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
        } else {
            forward = forward.normalize();
        }

        AABB reach = getBoundingBox().inflate(3.0D, 1.0D, 3.0D);
        for (LivingEntity target : server.getEntitiesOfClass(LivingEntity.class, reach,
                candidate -> candidate != this && HiveSwarmCoordinator.validTarget(this, candidate))) {
            Vec3 offset = target.position().subtract(position());
            Vec3 horizontal = new Vec3(offset.x, 0.0D, offset.z);
            if (offset.lengthSqr() > 9.0D || horizontal.lengthSqr() < 1.0E-8D
                    || forward.dot(horizontal.normalize()) < -0.15D || !hasLineOfSight(target)) continue;
            if (target.hurt(server.damageSources().mobAttack(this), 2.5F)) {
                target.knockback(0.3D, getX() - target.getX(), getZ() - target.getZ());
            }
        }
        server.sendParticles(ParticleTypes.SWEEP_ATTACK, getX() + forward.x, getY(0.5D),
                getZ() + forward.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        server.playSound(null, blockPosition(), ModSounds.HIVE_SPAWN_SKELETON_WHIP.get(),
                SoundSource.HOSTILE, 1.0F, 1.0F);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.HIVE_SPAWN_SKELETON_BONECRACK.get();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        level().playSound(null, pos, ModSounds.FLESH_BLOCK_STEP.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
    }

    /** One melee goal handles both close blade strikes and the mid-range whip. */
    private static final class InfectedSkeletonAttackGoal extends MeleeAttackGoal {
        private static final int WHIP_IMPACT_TICK = 4;
        private static final int WHIP_COOLDOWN_TICKS = 30;
        private final InfectedSkeletonEntity skeleton;
        private LivingEntity whipTarget;
        private int whipWindup;
        private int nextWhipTick;
        private int nextPikeTick;

        private InfectedSkeletonAttackGoal(InfectedSkeletonEntity skeleton, double speed) {
            super(skeleton, speed, false);
            this.skeleton = skeleton;
        }

        @Override
        public boolean canUse() { return skeleton.isVariantB() && super.canUse(); }

        @Override
        public boolean canContinueToUse() { return skeleton.isVariantB() && super.canContinueToUse(); }

        @Override
        public void stop() {
            super.stop();
            whipTarget = null;
            whipWindup = 0;
            skeleton.cancelWhipAnimation();
        }

        @Override
        protected void checkAndPerformAttack(LivingEntity target, double distanceToTargetSqr) {
            // A direct target assigned by HurtByTargetGoal may bypass target-selection predicates.
            // Do not clear it: movement/navigation may still bring a valid target into range.
            if (!skeleton.canAttackNow(target)) return;
            if (skeleton.isVariantB()) {
                whipTarget = null;
                whipWindup = 0;
                if (distanceToTargetSqr <= 16.0D) {
                    if (distanceToTargetSqr > 4.0D && skeleton.tickCount >= nextPikeTick) {
                        skeleton.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                        skeleton.doHurtTarget(target);
                        Vec3 charge = target.position().subtract(skeleton.position());
                        Vec3 horizontalCharge = new Vec3(charge.x, 0.0D, charge.z);
                        if (horizontalCharge.lengthSqr() > 1.0E-8D) skeleton.setDeltaMovement(horizontalCharge.normalize().scale(0.55D).add(0.0D, 0.08D, 0.0D));
                        nextPikeTick = skeleton.tickCount + 24;
                    } else if (distanceToTargetSqr <= 4.0D) {
                        super.checkAndPerformAttack(target, distanceToTargetSqr);
                    }
                }
                return;
            }
            boolean inWhipBand = distanceToTargetSqr >= 2.25D && distanceToTargetSqr <= 9.0D;
            if (whipTarget != null) {
                if (target != whipTarget || !inWhipBand || !skeleton.canAttackNow(target)) {
                    whipTarget = null;
                    whipWindup = 0;
                } else if (--whipWindup <= 0) {
                    skeleton.performWhipAttack();
                    nextWhipTick = skeleton.tickCount + WHIP_COOLDOWN_TICKS;
                    whipTarget = null;
                }
                return;
            }
            if (inWhipBand) {
                if (skeleton.tickCount >= nextWhipTick && skeleton.canAttackNow(target)) {
                    whipTarget = target;
                    whipWindup = WHIP_IMPACT_TICK;
                    skeleton.beginWhipAnimation();
                }
                return;
            }
            if (distanceToTargetSqr < 2.25D) super.checkAndPerformAttack(target, distanceToTargetSqr);
        }
    }
}
