# Carnis Adaptive Hivemind — версия 3.1.2

Ниже приведён полный текст каждого изменённого/созданного файла. Новые OGG не создавались.

## `src/main/java/com/carnis/mod/init/ModSounds.java`

```java

package com.carnis.mod.init;

import com.carnis.mod.CarnisMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, CarnisMod.MOD_ID);

    public static final RegistryObject<SoundEvent> INOCULATOR_FIRE =
            registerVariableRangeSound("item.inoculator.fire");
    public static final RegistryObject<SoundEvent> DART_HIT =
            registerVariableRangeSound("entity.dart.hit");

    public static final RegistryObject<SoundEvent> PURIFIER_IGNITE = registerVariableRangeSound("item.purifier.ignite");
    public static final RegistryObject<SoundEvent> PURIFIER_LOOP = registerVariableRangeSound("item.purifier.loop");
    public static final RegistryObject<SoundEvent> FLAMETHROWER_FIRE = registerVariableRangeSound("flamethrower_fire");
    public static final RegistryObject<SoundEvent> AMALGAM_SMASH = registerVariableRangeSound("amalgam_smash");
    public static final RegistryObject<SoundEvent> ORGANIC_CREAK = registerVariableRangeSound("organic_creak");
    public static final RegistryObject<SoundEvent> AMALGAM_ROAR = registerVariableRangeSound("amalgam_roar");

    public static final RegistryObject<SoundEvent> HEARTBEAT_LOOP = registerVariableRangeSound("heartbeat_loop");

    public static final RegistryObject<SoundEvent> AMALGAM_STEP = registerVariableRangeSound("amalgam_step");

    public static final RegistryObject<SoundEvent> PHANTOM_CREEPER =
            registerVariableRangeSound("phantom_creeper");

    public static final RegistryObject<SoundEvent> PHANTOM_FOOTSTEPS =
            registerVariableRangeSound("phantom_footsteps");

    public static final RegistryObject<SoundEvent> PHANTOM_WHISPER =
            registerVariableRangeSound("phantom_whisper");

    public static final RegistryObject<SoundEvent> PULSING_HEART_BEAT =
            registerVariableRangeSound("pulsing_heart_beat");

    public static final RegistryObject<SoundEvent> SYNAPSE_SHOCK =
            registerVariableRangeSound("synapse_shock");

    public static final RegistryObject<SoundEvent> SYNAPSE_RUPTURE =
            registerVariableRangeSound("synapse_rupture");

    public static final RegistryObject<SoundEvent> DIGESTOR_CHURN =
            registerVariableRangeSound("digestor_churn");

    public static final RegistryObject<SoundEvent> HIVE_EYE_SCREECH =
            registerVariableRangeSound("hive_eye_screech");
    public static final RegistryObject<SoundEvent> HIVE_ALARM =
            registerVariableRangeSound("hive_alarm");
    public static final RegistryObject<SoundEvent> HIVE_AMBIENT =
            registerVariableRangeSound("hive_ambient");
    public static final RegistryObject<SoundEvent> HIVE_AMBIENT_CLOSE =
            registerVariableRangeSound("hive_ambient_close");
    public static final RegistryObject<SoundEvent> HIVE_PULSE =
            registerVariableRangeSound("hive_pulse");
    public static final RegistryObject<SoundEvent> HIVE_AMBIENT_TONAL_STINGER =
            registerVariableRangeSound("hive_ambient_tonal_stinger");

    public static final RegistryObject<SoundEvent> FLESH_BLOCK_STEP =
            registerVariableRangeSound("flesh_block_step");
    public static final RegistryObject<SoundEvent> COMBAT_FLESH_HIT =
            registerVariableRangeSound("combat.flesh_hit");
    public static final RegistryObject<SoundEvent> COMBAT_FLESH_HIT_DEEP =
            registerVariableRangeSound("combat.flesh_hit_deep");
    public static final RegistryObject<SoundEvent> COMBAT_DISMEMBER =
            registerVariableRangeSound("combat.dismember");

    public static final RegistryObject<SoundEvent> HIVE_DETAIL_FLOW =
            registerVariableRangeSound("hive.detail.flow");
    public static final RegistryObject<SoundEvent> HIVE_DETAIL_MEMBRANE =
            registerVariableRangeSound("hive.detail.membrane");
    public static final RegistryObject<SoundEvent> HIVE_DETAIL_BUBBLES =
            registerVariableRangeSound("hive.detail.bubbles");
    public static final RegistryObject<SoundEvent> HIVE_DETAIL_CREAK =
            registerVariableRangeSound("hive.detail.creak");
    public static final RegistryObject<SoundEvent> HIVE_DETAIL_SCUTTLE =
            registerVariableRangeSound("hive.detail.scuttle");

    public static final RegistryObject<SoundEvent> HIVE_SPAWN_ALERT =
            registerVariableRangeSound("hive.spawn.alert");
    public static final RegistryObject<SoundEvent> HIVE_SPAWN_ATTACK =
            registerVariableRangeSound("hive.spawn.attack");
    public static final RegistryObject<SoundEvent> HIVE_SPAWN_IDLE =
            registerVariableRangeSound("hive.spawn.idle");
    public static final RegistryObject<SoundEvent> HIVE_SPAWN_HURT =
            registerVariableRangeSound("hive.spawn.hurt");
    public static final RegistryObject<SoundEvent> HIVE_SPAWN_DEATH =
            registerVariableRangeSound("hive.spawn.death");

    public static final RegistryObject<SoundEvent> CREEPER_RUPTURE =
            registerVariableRangeSound("creeper_rupture");

    public static final RegistryObject<SoundEvent> AMALGAMATION_FUSE =
            registerVariableRangeSound("amalgamation_fuse");

    public static final RegistryObject<SoundEvent> BONE_DEFLECT =
            registerVariableRangeSound("bone_deflect");

    public static final RegistryObject<SoundEvent> ACID_SPLASH =
            registerVariableRangeSound("acid_splash");

    public static final RegistryObject<SoundEvent> PUSTULE_BURST =
            registerVariableRangeSound("pustule_burst");

    public static final RegistryObject<SoundEvent> FLESH_AMALGAM_AMBIENT =
            registerVariableRangeSound("flesh_amalgam_ambient");

    public static final RegistryObject<SoundEvent> FLESH_AMALGAM_HURT =
            registerVariableRangeSound("flesh_amalgam_hurt");

    public static final RegistryObject<SoundEvent> FLESH_AMALGAM_DEATH =
            registerVariableRangeSound("flesh_amalgam_death");

    private ModSounds() {
    }

    private static RegistryObject<SoundEvent> registerVariableRangeSound(String name) {
        ResourceLocation soundId = new ResourceLocation(CarnisMod.MOD_ID, name);
        return SOUND_EVENTS.register(
                name,
                () -> SoundEvent.createVariableRangeEvent(soundId)
        );
    }

    public static void register(IEventBus modEventBus) {
        SOUND_EVENTS.register(modEventBus);
    }
}


```

**Аудит:** Добавлены DeferredRegister entries для звуков ambient, flesh, combat, hive detail и spawn; имеющиеся события проекта сохранены. Пакет оставлен `com.carnis.mod.init`, потому что это текущий путь и его импортирует основной мод.

## `src/main/resources/assets/carnis/sounds.json`

```json

{
  "acid_splash": {
    "subtitle": "subtitles.carnis.acid_splash",
    "sounds": [
      {
        "name": "carnis:entity/acid_splash",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "pustule_burst": {
    "subtitle": "carnis.subtitle.pustule_burst",
    "sounds": [
      "carnis:block/pustule_burst"
    ]
  },
  "amalgamation_fuse": {
    "subtitle": "subtitles.carnis.amalgamation_fuse",
    "sounds": [
      {
        "name": "carnis:entity/amalgamation_fuse",
        "volume": 1.1,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "bone_deflect": {
    "subtitle": "subtitles.carnis.bone_deflect",
    "sounds": [
      {
        "name": "carnis:entity/bone_deflect",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "digestor_churn": {
    "subtitle": "subtitles.carnis.digestor_churn",
    "sounds": [
      {
        "name": "carnis:block/digestor_churn",
        "volume": 0.9,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "flesh_amalgam_ambient": {
    "subtitle": "subtitles.carnis.flesh_amalgam_ambient",
    "sounds": [
      {
        "name": "carnis:entity/flesh_amalgam_ambient",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "flesh_amalgam_death": {
    "subtitle": "subtitles.carnis.flesh_amalgam_death",
    "sounds": [
      {
        "name": "carnis:entity/flesh_amalgam_death",
        "volume": 1.1,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "flesh_amalgam_hurt": {
    "subtitle": "subtitles.carnis.flesh_amalgam_hurt",
    "sounds": [
      {
        "name": "carnis:entity/flesh_amalgam_hurt",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "hive_eye_screech": {
    "subtitle": "carnis.subtitle.hive_eye_screech",
    "sounds": [
      {
        "name": "carnis:block/hive_eye_screech",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "phantom_creeper": {
    "subtitle": "subtitles.carnis.phantom_creeper",
    "sounds": [
      {
        "name": "carnis:hallucination/phantom_creeper",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "phantom_footsteps": {
    "subtitle": "subtitles.carnis.phantom_footsteps",
    "sounds": [
      {
        "name": "carnis:hallucination/phantom_footsteps",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "phantom_whisper": {
    "subtitle": "subtitles.carnis.phantom_whisper",
    "sounds": [
      {
        "name": "carnis:hallucination/phantom_whisper",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "synapse_rupture": {
    "subtitle": "subtitles.carnis.synapse_rupture",
    "sounds": [
      {
        "name": "carnis:block/synapse_fire",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "amalgam_step": {
    "subtitle": "subtitles.carnis.amalgam_step",
    "sounds": [
      "carnis:entity/amalgam_step"
    ]
  },
  "heartbeat_loop": {
    "subtitle": "subtitles.carnis.heartbeat_loop",
    "sounds": [
      "carnis:block/hive_heartbeat"
    ]
  },
  "amalgam_roar": {
    "subtitle": "subtitles.carnis.amalgam_roar",
    "sounds": [
      {
        "name": "carnis:entity/amalgam_roar",
        "volume": 1.0,
        "pitch": 0.75
      }
    ]
  },
  "flamethrower_fire": {
    "subtitle": "subtitles.carnis.flamethrower_fire",
    "sounds": [
      {
        "name": "carnis:entity/flamethrower_fire",
        "stream": false
      }
    ]
  },
  "synapse_shock": {
    "subtitle": "subtitles.carnis.synapse_shock",
    "sounds": [
      {
        "name": "carnis:block/nervous_twitch",
        "pitch": 1.2
      }
    ]
  },
  "pulsing_heart_beat": {
    "subtitle": "subtitles.carnis.pulsing_heart_beat",
    "sounds": [
      "carnis:block/heart_pulse"
    ]
  },
  "item.inoculator.fire": {
    "subtitle": "subtitles.carnis.inoculator_fire",
    "sounds": [
      {
        "name": "carnis:item/inoculator_fire",
        "volume": 1.0,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "entity.dart.hit": {
    "subtitle": "subtitles.carnis.dart_hit",
    "sounds": [
      {
        "name": "carnis:item/dart_hit",
        "volume": 0.8,
        "pitch": 1.0,
        "stream": false
      }
    ]
  },
  "item.purifier.ignite": {
    "subtitle": "subtitles.carnis.purifier_ignite",
    "sounds": [
      {
        "name": "carnis:item/purifier_ignite",
        "volume": 1.0,
        "pitch": 1.0
      }
    ]
  },
  "item.purifier.loop": {
    "subtitle": "subtitles.carnis.purifier_loop",
    "sounds": [
      {
        "name": "carnis:item/purifier_loop",
        "volume": 1.0,
        "pitch": 1.0
      }
    ]
  },
  "amalgam_smash": {
    "subtitle": "subtitles.carnis.amalgam_smash",
    "sounds": [
      "carnis:entity/amalgam_smash"
    ]
  },
  "organic_creak": {
    "subtitle": "subtitles.carnis.organic_creak",
    "sounds": [
      "carnis:entity/organic_creak"
    ]
  },
  "hive_alarm": {
    "subtitle": "carnis.subtitle.hive_alarm",
    "sounds": [
      {
        "name": "carnis:block/hive_alarm",
        "volume": 1.0,
        "pitch": 0.9,
        "stream": false
      }
    ]
  },
  "hive_ambient": {
    "subtitle": "carnis.subtitle.hive_ambient",
    "sounds": [
      {
        "name": "carnis:amb/hive_ambient_01",
        "weight": 1,
        "stream": true
      },
      {
        "name": "carnis:amb/hive_ambient_02",
        "weight": 1,
        "stream": true
      },
      {
        "name": "carnis:amb/hive_ambient_03",
        "weight": 1,
        "stream": true
      }
    ]
  },
  "hive_ambient_close": {
    "subtitle": "carnis.subtitle.hive_ambient_close",
    "sounds": [
      {
        "name": "carnis:amb/hive_ambient_close_01",
        "weight": 1,
        "stream": true
      },
      {
        "name": "carnis:amb/hive_ambient_close_02",
        "weight": 1,
        "stream": true
      }
    ]
  },
  "hive_pulse": {
    "subtitle": "carnis.subtitle.hive_pulse",
    "sounds": [
      {
        "name": "carnis:amb/hive_pulse_01",
        "weight": 1
      },
      {
        "name": "carnis:amb/hive_pulse_02",
        "weight": 1
      },
      {
        "name": "carnis:amb/hive_pulse_03",
        "weight": 1
      }
    ]
  },
  "hive_ambient_tonal_stinger": {
    "subtitle": "carnis.subtitle.hive_ambient_tonal_stinger",
    "sounds": [
      {
        "name": "carnis:amb/hive_ambient_tonal_stinger",
        "weight": 1,
        "stream": true
      }
    ]
  },
  "creeper_rupture": {
    "subtitle": "subtitles.carnis.creeper_rupture",
    "sounds": [
      {
        "name": "carnis:block/creeper_rupture",
        "pitch": 0.9,
        "volume": 1.0
      }
    ]
  },
  "flesh_block_step": {
    "subtitle": "carnis.subtitle.flesh_block_step",
    "sounds": [
      {
        "name": "carnis:flesh/flesh_block_step_01",
        "weight": 1
      },
      {
        "name": "carnis:flesh/flesh_block_step_02",
        "weight": 1
      },
      {
        "name": "carnis:flesh/flesh_block_step_03",
        "weight": 1
      }
    ]
  },
  "combat.flesh_hit": {
    "subtitle": "carnis.subtitle.combat_flesh_hit",
    "sounds": [
      {
        "name": "carnis:combat/combat_flesh_hit_01",
        "weight": 1
      },
      {
        "name": "carnis:combat/combat_flesh_hit_02",
        "weight": 1
      },
      {
        "name": "carnis:combat/combat_flesh_hit_03",
        "weight": 1
      }
    ]
  },
  "combat.flesh_hit_deep": {
    "subtitle": "carnis.subtitle.combat_flesh_hit_deep",
    "sounds": [
      {
        "name": "carnis:combat/combat_flesh_hit_deep_01_axe",
        "weight": 1
      },
      {
        "name": "carnis:combat/combat_flesh_hit_deep_02_crit",
        "weight": 1
      },
      {
        "name": "carnis:combat/combat_flesh_hit_deep_03_blast",
        "weight": 1
      }
    ]
  },
  "combat.dismember": {
    "subtitle": "carnis.subtitle.combat_dismember",
    "sounds": [
      {
        "name": "carnis:combat/combat_dismember_01_ribs",
        "weight": 1
      },
      {
        "name": "carnis:combat/combat_dismember_02_pustule",
        "weight": 1
      },
      {
        "name": "carnis:combat/combat_dismember_03_sinew",
        "weight": 1
      },
      {
        "name": "carnis:combat/combat_dismember_04_plate",
        "weight": 1
      },
      {
        "name": "carnis:combat/combat_dismember_05_limb",
        "weight": 1
      }
    ]
  },
  "hive.detail.flow": {
    "subtitle": "carnis.subtitle.hive_detail_flow",
    "sounds": [
      {
        "name": "carnis:hive/detail_flow_01",
        "weight": 1
      },
      {
        "name": "carnis:hive/detail_flow_02",
        "weight": 1
      }
    ]
  },
  "hive.detail.membrane": {
    "subtitle": "carnis.subtitle.hive_detail_membrane",
    "sounds": [
      {
        "name": "carnis:hive/detail_membrane_01",
        "weight": 1
      }
    ]
  },
  "hive.detail.bubbles": {
    "subtitle": "carnis.subtitle.hive_detail_bubbles",
    "sounds": [
      {
        "name": "carnis:hive/detail_bubbles_01",
        "weight": 1
      }
    ]
  },
  "hive.detail.creak": {
    "subtitle": "carnis.subtitle.hive_detail_creak",
    "sounds": [
      {
        "name": "carnis:hive/detail_creak_01",
        "weight": 1
      }
    ]
  },
  "hive.detail.scuttle": {
    "subtitle": "carnis.subtitle.hive_detail_scuttle",
    "sounds": [
      {
        "name": "carnis:hive/detail_scuttle_01",
        "weight": 1
      }
    ]
  },
  "hive.spawn.alert": {
    "subtitle": "carnis.subtitle.hive_spawn_alert",
    "sounds": [
      {
        "name": "carnis:hive/hive_spawn_alert_01",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_alert_02",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_alert_03",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_alert_04",
        "weight": 1
      }
    ]
  },
  "hive.spawn.attack": {
    "subtitle": "carnis.subtitle.hive_spawn_attack",
    "sounds": [
      {
        "name": "carnis:hive/hive_spawn_attack_01",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_attack_02",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_attack_03",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_attack_04",
        "weight": 1
      }
    ]
  },
  "hive.spawn.idle": {
    "subtitle": "carnis.subtitle.hive_spawn_idle",
    "sounds": [
      {
        "name": "carnis:hive/hive_spawn_idle_01",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_idle_02",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_idle_03",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_idle_04",
        "weight": 1
      }
    ]
  },
  "hive.spawn.hurt": {
    "subtitle": "carnis.subtitle.hive_spawn_hurt",
    "sounds": [
      {
        "name": "carnis:hive/hive_spawn_hurt_01",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_hurt_02",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_hurt_03",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_hurt_04",
        "weight": 1
      }
    ]
  },
  "hive.spawn.death": {
    "subtitle": "carnis.subtitle.hive_spawn_death",
    "sounds": [
      {
        "name": "carnis:hive/hive_spawn_death_01",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_death_02",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_death_03",
        "weight": 1
      },
      {
        "name": "carnis:hive/hive_spawn_death_04",
        "weight": 1
      }
    ]
  }
}


```

**Аудит:** Мастер-файл сохраняет прежние sound events и добавляет все 49 заданных путей. Длинные ambient/stinger используют `stream: true`; combat-группы используют веса.

## `src/main/java/com/carnis/mod/sound/CarnisCombatSounds.java`

```java

package com.carnis.mod.sound;

import com.carnis.mod.CarnisMod;
import com.carnis.mod.init.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/** Server-side combat sound routing and short delayed dismemberment playback. */
@Mod.EventBusSubscriber(modid = CarnisMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CarnisCombatSounds {
    private static final long HEAVY_HIT_COOLDOWN_TICKS = 2L;
    private static final long DISMEMBER_COOLDOWN_TICKS = 20L;

    private static final Map<LivingEntity, Long> LAST_HEAVY_HIT = new WeakHashMap<>();
    private static final Map<LivingEntity, Long> LAST_DISMEMBER = new WeakHashMap<>();
    private static final List<PendingSound> PENDING_DISMEMBER_SOUNDS = new ArrayList<>();

    private CarnisCombatSounds() { }

    /** Plays the regular flesh-hit variation for a server-side target. */
    public static void onHit(LivingEntity target) {
        ServerLevel level = serverLevel(target);
        if (level == null) return;
        playAt(level, target, ModSounds.COMBAT_FLESH_HIT.get(), 0.85F,
                0.92F + target.getRandom().nextFloat() * 0.16F);
    }

    /** Plays a deep hit at most once per target every two game ticks (100 ms). */
    public static void onHeavyHit(LivingEntity target) {
        ServerLevel level = serverLevel(target);
        if (level == null) return;

        long now = level.getGameTime();
        synchronized (LAST_HEAVY_HIT) {
            Long previous = LAST_HEAVY_HIT.get(target);
            if (previous != null && now >= previous && now - previous < HEAVY_HIT_COOLDOWN_TICKS) return;
            LAST_HEAVY_HIT.put(target, now);
        }

        playAt(level, target, ModSounds.COMBAT_FLESH_HIT_DEEP.get(), 1.0F,
                0.90F + target.getRandom().nextFloat() * 0.20F);
    }

    /**
     * Schedules a dismemberment sound 3–5 ticks after the hit, with a one-second per-target cooldown.
     * The caller supplies the current game time so this can be used by existing combat/dismemberment logic.
     */
    public static void onDismember(LivingEntity target, DamageSource src, long now) {
        ServerLevel level = serverLevel(target);
        if (level == null || src == null) return;

        synchronized (LAST_DISMEMBER) {
            Long previous = LAST_DISMEMBER.get(target);
            if (previous != null && now >= previous && now - previous < DISMEMBER_COOLDOWN_TICKS) return;
            LAST_DISMEMBER.put(target, now);
        }

        int delay = 3 + target.getRandom().nextInt(3);
        float volume = src.getEntity() == null ? 0.85F : 1.0F;
        float pitch = 0.94F + target.getRandom().nextFloat() * 0.12F;
        PendingSound pending = new PendingSound(new WeakReference<>(level),
                level.getGameTime() + delay, target.getX(), target.getY(), target.getZ(),
                ModSounds.COMBAT_DISMEMBER.get(), volume, pitch);
        synchronized (PENDING_DISMEMBER_SOUNDS) {
            PENDING_DISMEMBER_SOUNDS.add(pending);
        }
    }

    /** Ordinary direct attacks trigger a flesh hit; callers can explicitly classify heavy hits. */
    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        LivingEntity target = event.getEntity();
        if (event.isCanceled() || !(target.level() instanceof ServerLevel) || event.getAmount() <= 0.0F) return;
        DamageSource source = event.getSource();
        if (source.getEntity() == target || source.getEntity() == null && source.getDirectEntity() == null) return;
        onHit(target);
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) return;

        List<PendingSound> ready = new ArrayList<>();
        synchronized (PENDING_DISMEMBER_SOUNDS) {
            Iterator<PendingSound> iterator = PENDING_DISMEMBER_SOUNDS.iterator();
            while (iterator.hasNext()) {
                PendingSound pending = iterator.next();
                ServerLevel pendingLevel = pending.level().get();
                if (pendingLevel == null) {
                    iterator.remove();
                } else if (pendingLevel == level && level.getGameTime() >= pending.dueAt()) {
                    ready.add(pending);
                    iterator.remove();
                }
            }
        }

        for (PendingSound pending : ready) {
            level.playSound(null, pending.x(), pending.y(), pending.z(), pending.sound(),
                    SoundSource.HOSTILE, pending.volume(), pending.pitch());
        }
    }

    private static ServerLevel serverLevel(LivingEntity target) {
        return target.level() instanceof ServerLevel level ? level : null;
    }

    private static void playAt(ServerLevel level, LivingEntity target, SoundEvent sound, float volume, float pitch) {
        level.playSound(null, target.getX(), target.getY(), target.getZ(), sound,
                SoundSource.HOSTILE, volume, pitch);
    }

    private record PendingSound(WeakReference<ServerLevel> level, long dueAt,
                                double x, double y, double z, SoundEvent sound,
                                float volume, float pitch) { }
}


```

**Аудит:** Обычные direct hits подключены к flesh-hit; `onHeavyHit` ограничен двумя тиками на цель. `onDismember` ставит звук в очередь на 3–5 тиков и применяет cooldown 20 тиков.

## `src/main/resources/assets/carnis/lang/en_us.json`

```json

{
  "carnis.subtitle.hive_ambient": "Hive ambience",
  "carnis.subtitle.hive_ambient_close": "Close hive ambience",
  "carnis.subtitle.hive_pulse": "Hive pulse",
  "carnis.subtitle.hive_ambient_tonal_stinger": "Distant hive tone",
  "carnis.subtitle.flesh_block_step": "Wet flesh underfoot",
  "carnis.subtitle.combat_flesh_hit": "Flesh impact",
  "carnis.subtitle.combat_flesh_hit_deep": "Heavy flesh impact",
  "carnis.subtitle.combat_dismember": "Dismemberment",
  "carnis.subtitle.hive_detail_flow": "Hive fluid flowing",
  "carnis.subtitle.hive_detail_membrane": "Hive membrane shifting",
  "carnis.subtitle.hive_detail_bubbles": "Bubbles in the hive",
  "carnis.subtitle.hive_detail_creak": "Hive structure creaking",
  "carnis.subtitle.hive_detail_scuttle": "Something scuttles in the hive",
  "carnis.subtitle.hive_spawn_alert": "Hive creature alerted",
  "carnis.subtitle.hive_spawn_attack": "Hive creature attacks",
  "carnis.subtitle.hive_spawn_idle": "Hive creature stirs",
  "carnis.subtitle.hive_spawn_hurt": "Hive creature hurt",
  "carnis.subtitle.hive_spawn_death": "Hive creature dies",
  "carnis.subtitle.pustule_burst": "Pustule bursts",
  "carnis.subtitle.hive_eye_screech": "Hive eye screeches",
  "carnis.subtitle.hive_alarm": "Hive alarm",
  "subtitles.carnis.acid_splash": "Acid splashes",
  "subtitles.carnis.pustule_burst": "Pustule bursts",
  "subtitles.carnis.amalgamation_fuse": "Amalgamation begins",
  "subtitles.carnis.bone_deflect": "Bone deflects a blow",
  "subtitles.carnis.digestor_churn": "Digestor churns",
  "subtitles.carnis.flesh_amalgam_ambient": "Flesh amalgam groans",
  "subtitles.carnis.flesh_amalgam_death": "Flesh amalgam dies",
  "subtitles.carnis.flesh_amalgam_hurt": "Flesh amalgam hurt",
  "subtitles.carnis.hive_eye_screech": "Hive eye screeches",
  "subtitles.carnis.phantom_creeper": "Phantom creeper hisses",
  "subtitles.carnis.phantom_footsteps": "Phantom footsteps",
  "subtitles.carnis.phantom_whisper": "A phantom whispers",
  "subtitles.carnis.synapse_rupture": "Synapse ruptures",
  "subtitles.carnis.amalgam_step": "Amalgam steps",
  "subtitles.carnis.heartbeat_loop": "Heartbeat",
  "subtitles.carnis.amalgam_roar": "Amalgam roars",
  "subtitles.carnis.flamethrower_fire": "Flamethrower fires",
  "subtitles.carnis.synapse_shock": "Synapse shocks",
  "subtitles.carnis.pulsing_heart_beat": "Pulsing heart beats",
  "subtitles.carnis.inoculator_fire": "Inoculator fires",
  "subtitles.carnis.dart_hit": "Dart hits",
  "subtitles.carnis.purifier_ignite": "Purifier ignites",
  "subtitles.carnis.purifier_loop": "Purifier runs",
  "subtitles.carnis.amalgam_smash": "Amalgam smashes",
  "subtitles.carnis.organic_creak": "Organic creak",
  "subtitles.carnis.hive_alarm": "Hive alarm",
  "subtitles.carnis.creeper_rupture": "Creeper ruptures"
}


```

**Аудит:** Добавлены английские `carnis.subtitle.*` подписи для новых звуков и органов; существующие legacy subtitle keys также локализованы.

## `src/main/resources/assets/carnis/lang/ru_ru.json`

```json

{
  "carnis.subtitle.hive_ambient": "Гул улья",
  "carnis.subtitle.hive_ambient_close": "Близкий гул улья",
  "carnis.subtitle.hive_pulse": "Пульс улья",
  "carnis.subtitle.hive_ambient_tonal_stinger": "Отдалённый тон улья",
  "carnis.subtitle.flesh_block_step": "Хлюпанье плоти под ногами",
  "carnis.subtitle.combat_flesh_hit": "Удар по плоти",
  "carnis.subtitle.combat_flesh_hit_deep": "Тяжёлый удар по плоти",
  "carnis.subtitle.combat_dismember": "Разрывание плоти",
  "carnis.subtitle.hive_detail_flow": "Течение жидкости в улье",
  "carnis.subtitle.hive_detail_membrane": "Движение мембраны улья",
  "carnis.subtitle.hive_detail_bubbles": "Пузырьки в улье",
  "carnis.subtitle.hive_detail_creak": "Скрип улья",
  "carnis.subtitle.hive_detail_scuttle": "Кто-то шуршит в улье",
  "carnis.subtitle.hive_spawn_alert": "Существо улья насторожилось",
  "carnis.subtitle.hive_spawn_attack": "Существо улья атакует",
  "carnis.subtitle.hive_spawn_idle": "Существо улья шевелится",
  "carnis.subtitle.hive_spawn_hurt": "Существо улья ранено",
  "carnis.subtitle.hive_spawn_death": "Существо улья погибает",
  "carnis.subtitle.pustule_burst": "Пустула лопнула",
  "carnis.subtitle.hive_eye_screech": "Улей-глаз визжит",
  "carnis.subtitle.hive_alarm": "Тревога улья",
  "subtitles.carnis.acid_splash": "Кислота шипит",
  "subtitles.carnis.pustule_burst": "Пустула лопнула",
  "subtitles.carnis.amalgamation_fuse": "Слияние начинается",
  "subtitles.carnis.bone_deflect": "Кость отражает удар",
  "subtitles.carnis.digestor_churn": "Перевариватель урчит",
  "subtitles.carnis.flesh_amalgam_ambient": "Плотский амальгам стонет",
  "subtitles.carnis.flesh_amalgam_death": "Плотский амальгам погибает",
  "subtitles.carnis.flesh_amalgam_hurt": "Плотский амальгам ранен",
  "subtitles.carnis.hive_eye_screech": "Улей-глаз визжит",
  "subtitles.carnis.phantom_creeper": "Фантомный крипер шипит",
  "subtitles.carnis.phantom_footsteps": "Фантомные шаги",
  "subtitles.carnis.phantom_whisper": "Фантом шепчет",
  "subtitles.carnis.synapse_rupture": "Синапс разрывается",
  "subtitles.carnis.amalgam_step": "Шаги амальгама",
  "subtitles.carnis.heartbeat_loop": "Сердцебиение",
  "subtitles.carnis.amalgam_roar": "Амальгам рычит",
  "subtitles.carnis.flamethrower_fire": "Огнемёт стреляет",
  "subtitles.carnis.synapse_shock": "Разряд синапса",
  "subtitles.carnis.pulsing_heart_beat": "Пульсирующее сердце бьётся",
  "subtitles.carnis.inoculator_fire": "Инокулятор стреляет",
  "subtitles.carnis.dart_hit": "Дротик попал",
  "subtitles.carnis.purifier_ignite": "Очиститель зажёгся",
  "subtitles.carnis.purifier_loop": "Очиститель работает",
  "subtitles.carnis.amalgam_smash": "Амальгам бьёт",
  "subtitles.carnis.organic_creak": "Органический скрип",
  "subtitles.carnis.hive_alarm": "Тревога улья",
  "subtitles.carnis.creeper_rupture": "Крипер разрывается"
}


```

**Аудит:** Добавлены русские `carnis.subtitle.*` подписи для новых звуков и органов; существующие legacy subtitle keys также локализованы.
