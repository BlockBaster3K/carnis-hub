# 3.4.10 — предметы, horror p1 (частичная партия: 7 из 21)

## Что сделано
Семь PNG переработаны в органическом horror-ключе; модели не менялись. Файлы установлены в рабочую копию проекта и отдельно лежат в архиве по путям `assets/carnis/textures/item/`. Исходники этих семи PNG сохранены в `analysis_horror_3410/baseline_changed_assets/textures/item/`.

| PNG | Размер | Байт | SHA-256 |
|---|---:|---:|---|
| `textures/item/amalgam_bile_glob.png` | 64×64 RGBA | 7148 | `324be2712930416e41d9c0600f3af3502495f384ceb8d13e06fdf12419773a4a` |
| `textures/item/bone_scythe_arm.png` | 64×64 RGBA | 4168 | `364d589f69320a2daeffe83d3d19e5780aa977e4c132bfb6bca34f07527d5dea` |
| `textures/item/cerebral_nexus_spawn_egg.png` | 64×64 RGBA | 6541 | `f7ee8cef025297d0c83bcd1d964dd42edcdb4df1723d0d851e3ba2135aed419d` |
| `textures/item/hive_sentinel_spawn_egg.png` | 64×64 RGBA | 5690 | `223e8c911a65de61c854be53af0a2e1120f2717b1b4a7a76a62dce0118cf555c` |
| `textures/item/parasitic_tendril_spawn_egg.png` | 64×64 RGBA | 6169 | `0a72908cb11853303b1e08346bdb41cba2df54f901ed39f2c5db4f8e396b1b52` |
| `textures/item/flesh_spat.png` | 64×64 RGBA | 5460 | `6d513e5da17e9964b1597118f63dd28adabca3628edec4518a0694b7a6d29f53` |
| `textures/item/neural_binding_matrix.png` | 64×64 RGBA | 8680 | `5f30b06a4d66a1cd0e612f69808aef131a7f0951d2f169d15abf68efdb75cbb3` |

Оригиналы всех семи — 16×16; повышение до 64×64 меняет плотность деталей. `manifest.json` содержит также хеши оригиналов и используемых моделей. `preview.png` — просмотр на двух фонах и приближение 16 px.

## Что не подтверждено
- Это художественная частичная сдача, а не подтверждение финальной приёмки и не PASS в Minecraft. Прозрачность/вырезание, инвентарь, рука и дроп должны быть проверены в общей пакетной проверке игры. Мелкие детали на 16 px теряются.
- Три яйца зарегистрированы как `ForgeSpawnEggItem` с цветами в коде. Возможное окрашивание текстур движком и фактический итоговый цвет не проверены: обязательно проверить в игре. Изображение предпросмотра не моделирует tint.
- Контур проверен на выход к границе, явный зелёный/пурпурный spill и отделённые компоненты; это не доказывает отсутствие всех визуальных артефактов.
- `creeping_tendrils.png` не входит в партию: текущий кандидат слишком тонкий и слабо читается на 16 px; оригинал в проекте не заменён.

## Далее
Предметы: ещё 14 из 21 не сданы; ни один из них не утверждён как соответствующий новой планке:

- `antibiotics.png`
- `bio_purifier.png`
- `bio_purifier_geo.png`
- `bio_purifier_glowmask.png`
- `creeping_tendrils.png`
- `neuro_resonator_boots.png`
- `neuro_resonator_chestplate.png`
- `neuro_resonator_helmet.png`
- `neuro_resonator_leggings.png`
- `pneumatic_inoculator_geo.png`
- `purification_dart.png`
- `research_journal.png`
- `tainted_sludge_bucket.png`
- `viral_dart.png`

После предметов — существа 19 + geo 16, затем armor/gui/particle и прочие категории по согласованной очереди. Блоки: 16 приняты, ещё 33 требуют работы, 2 под LOCK.

LOCK: 9/9 хешей совпали с исходным baseline после установки. Модели предметов, геометрия, код и остальные PNG этой партией не менялись.
