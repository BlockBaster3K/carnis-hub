package com.carnis.mod.client.model;

import com.carnis.mod.entity.InfectedZombieEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public final class InfectedZombieGeoModel extends GeoModel<InfectedZombieEntity> {
    @Override public ResourceLocation getModelResource(InfectedZombieEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA() ? "geo/entity/infected_zombie.geo.json" : "geo/entity/infected_zombie_b.geo.json");
    }
    @Override public ResourceLocation getTextureResource(InfectedZombieEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA() ? "textures/entity/infected_zombie.png" : "textures/entity/infected_zombie_b.png");
    }
    @Override public ResourceLocation getAnimationResource(InfectedZombieEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA() ? "animations/entity/infected_zombie.animation.json" : "animations/entity/infected_zombie_b.animation.json");
    }
}
