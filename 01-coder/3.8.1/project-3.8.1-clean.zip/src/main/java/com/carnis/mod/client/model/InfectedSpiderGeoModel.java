package com.carnis.mod.client.model;

import com.carnis.mod.entity.InfectedSpiderEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/**
 * The model resolves the geometry, texture, and animation resources.
 *
 * Variant B is gameplay-distinct and now ships its own art: separate geometry,
 * texture and animation set under the "_b" suffix. The choice is made per
 * entity through isVariantA(), exactly as the zombie and skeleton models do.
 */
public final class InfectedSpiderGeoModel extends GeoModel<InfectedSpiderEntity> {
    @Override public ResourceLocation getModelResource(InfectedSpiderEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA()
                ? "geo/entity/infected_spider.geo.json"
                : "geo/entity/infected_spider_b.geo.json");
    }
    @Override public ResourceLocation getTextureResource(InfectedSpiderEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA()
                ? "textures/entity/infected_spider.png"
                : "textures/entity/infected_spider_b.png");
    }
    @Override public ResourceLocation getAnimationResource(InfectedSpiderEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA()
                ? "animations/entity/infected_spider.animation.json"
                : "animations/entity/infected_spider_b.animation.json");
    }
}
