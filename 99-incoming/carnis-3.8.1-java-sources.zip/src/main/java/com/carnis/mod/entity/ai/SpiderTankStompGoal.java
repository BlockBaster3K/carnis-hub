package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.InfectedSpiderEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Variant-B short-range ground slam: radial push and a temporary shield-item cooldown. */
public final class SpiderTankStompGoal extends Goal {
    private final InfectedSpiderEntity spider;
    private int cooldown;
    public SpiderTankStompGoal(InfectedSpiderEntity spider) {
        this.spider = spider;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }
    @Override public boolean canUse() {
        if (cooldown > 0) cooldown--;
        LivingEntity target = spider.getTarget();
        return !spider.isVariantA() && cooldown == 0 && target != null && target.isAlive()
                && spider.distanceToSqr(target) <= 9.0D && spider.onGround();
    }
    @Override public boolean canContinueToUse() { return false; }
    @Override public void start() {
        cooldown = 100;
        if (!(spider.level() instanceof ServerLevel server)) return;
        for (LivingEntity victim : server.getEntitiesOfClass(LivingEntity.class,
                spider.getBoundingBox().inflate(3.0D, 1.0D, 3.0D),
                candidate -> candidate != spider && HiveSwarmCoordinator.validTarget(spider, candidate))) {
            Vec3 direction = victim.position().subtract(spider.position());
            if (direction.horizontalDistanceSqr() < 1.0E-8D) direction = new Vec3(1.0D, 0.0D, 0.0D);
            victim.knockback(1.4D, -direction.x, -direction.z);
            if (victim instanceof Player player) player.getCooldowns().addCooldown(Items.SHIELD, 100);
        }
        spider.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
    }
}
