package com.carnis.mod.entity;

import com.carnis.mod.entity.ai.CarnisFeedingGoal;
import com.carnis.mod.entity.ai.CarnisGestationGoal;
import com.carnis.mod.entity.ai.CarnisHuntPreyGoal;
import com.carnis.mod.entity.ai.HiveDefendHeartGoal;
import com.carnis.mod.entity.ai.HiveEscortLeaderGoal;
import com.carnis.mod.entity.ai.HiveSwarmCoordinator;
import com.carnis.mod.init.ModSounds;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public final class InfectedZombieEntity extends HiveEntity implements HivemindLinkedMob, AssimilatingMob, GeoEntity {
    private static final long BIOMASS_VALUE = 3L;
    private static final EntityDataAccessor<Integer> COMBAT_VARIANT =
            SynchedEntityData.defineId(InfectedZombieEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> ASSIMILATING =
            SynchedEntityData.defineId(InfectedZombieEntity.class, EntityDataSerializers.BOOLEAN);
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.infected_zombie.idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.infected_zombie.walk");
    private static final RawAnimation WALK_B = RawAnimation.begin().thenLoop("animation.infected_zombie_b.walk");
    private static final RawAnimation ASSIMILATE = RawAnimation.begin().thenLoop("animation.infected_zombie.assimilate");
    private static final RawAnimation PULSE = RawAnimation.begin().thenLoop("animation.infected_zombie.pulsing");
    private static final RawAnimation PULSE_B = RawAnimation.begin().thenLoop("animation.infected_zombie_b.pulsing");
    private static final RawAnimation ASSIMILATE_B = RawAnimation.begin().thenLoop("animation.infected_zombie_b.assimilate");
    private static final RawAnimation ATTACK = RawAnimation.begin().thenPlay("animation.infected_zombie.attack");
    private static final RawAnimation ATTACK_B = RawAnimation.begin().thenPlay("animation.infected_zombie_b.attack");
    private static final RawAnimation SCYTHE_CLEAVE = RawAnimation.begin().thenPlay("animation.infected_zombie.scythe_cleave");
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    public InfectedZombieEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(COMBAT_VARIANT, InfectedVariant.A.id());
        entityData.define(ASSIMILATING, false);
    }

    public InfectedVariant getCombatVariant() { return InfectedVariant.fromId(entityData.get(COMBAT_VARIANT)); }
    public boolean isVariantA() { return getCombatVariant() == InfectedVariant.A; }
    public void setCombatVariant(InfectedVariant variant) {
        entityData.set(COMBAT_VARIANT, variant.id());
        applyVariantAttributes(variant);
    }
    private void applyVariantAttributes(InfectedVariant variant) {
        VariantAttributes.apply(this, variant);
    }
    @Override
    public net.minecraft.world.entity.SpawnGroupData finalizeSpawn(
            net.minecraft.world.level.ServerLevelAccessor level, net.minecraft.world.DifficultyInstance difficulty,
            net.minecraft.world.entity.MobSpawnType spawnType, net.minecraft.world.entity.SpawnGroupData groupData,
            net.minecraft.nbt.CompoundTag tag) {
        net.minecraft.world.entity.SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData, tag);
        // Выбор варианта здесь, а не в конструкторе: entityData доступен
        // только после defineSynchedData(), иначе значение откатывается к A.
        if (tag == null || !tag.contains(InfectedVariant.NBT_KEY, net.minecraft.nbt.Tag.TAG_INT)) {
            setCombatVariant(InfectedVariant.random(random));
        }
        applyVariantAttributes(getCombatVariant());
        setHealth(getMaxHealth());
        return result;
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(InfectedVariant.NBT_KEY, getCombatVariant().id());
    }
    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains(InfectedVariant.NBT_KEY, net.minecraft.nbt.Tag.TAG_INT)) {
            setCombatVariant(InfectedVariant.fromId(tag.getInt(InfectedVariant.NBT_KEY)));
        } else {
            // /summon и прочие пути без NBT не проходят через finalizeSpawn,
            // поэтому вариант иначе навсегда остался бы A из defineSynchedData().
            setCombatVariant(InfectedVariant.random(random));
        }
    }

    @Override
    public boolean isAssimilating() {
        return entityData.get(ASSIMILATING);
    }

    @Override
    public void setAssimilating(boolean assimilating) {
        entityData.set(ASSIMILATING, assimilating);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement", 3, state -> {
            if (isAssimilating()) return state.setAndContinue(isVariantA() ? ASSIMILATE : ASSIMILATE_B);
            if (state.isMoving()) {
                state.getController().setAnimationSpeed(WalkAnimationSync.factor(this));
                return state.setAndContinue(isVariantA() ? WALK : WALK_B);
            }
            return state.setAndContinue(IDLE);
        }));
        controllers.add(new AnimationController<>(this, "pulsing", 0, state -> {
            if (isAssimilating()) return PlayState.STOP;
            return state.setAndContinue(isVariantA() ? PULSE : PULSE_B);
        }));
        controllers.add(new AnimationController<>(this, "action", 1, state -> {
            if (!isAssimilating() && swinging) return state.setAndContinue(isVariantA() ? ATTACK : ATTACK_B);
            state.getController().forceAnimationReset();
            return PlayState.STOP;
        }).triggerableAnim("scythe_cleave", SCYTHE_CLEAVE));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new HiveDefendHeartGoal(this));
        goalSelector.addGoal(1, new com.carnis.mod.entity.ai.ZombieScytheCleaveGoal(this));
        goalSelector.addGoal(1, new com.carnis.mod.entity.ai.VariantMeleeAttackGoal(this, 1.3D));
        goalSelector.addGoal(2, new com.carnis.mod.entity.ai.ZombieRipperLeapGoal(this, 0.55F));
        goalSelector.addGoal(2, new CarnisFeedingGoal(this));
        goalSelector.addGoal(3, new CarnisGestationGoal(this));
        goalSelector.addGoal(4, new RandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(5, new HiveEscortLeaderGoal(this));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 20, true, false,
                target -> HiveSwarmCoordinator.validTarget(this, target)));
        targetSelector.addGoal(2, new HurtByTargetGoal(this));
        targetSelector.addGoal(3, new CarnisHuntPreyGoal(this));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 35.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.5D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 16.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.3D)
                .add(Attributes.ARMOR, 2.0D);
    }

    @Override
    public long getBiomassValue() {
        return BIOMASS_VALUE;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.HIVE_SPAWN_IDLE.get();
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        if (!(target instanceof LivingEntity livingTarget)
                || !HiveSwarmCoordinator.validTarget(this, livingTarget)) return false;
        boolean success = super.doHurtTarget(target);
        if (success && !level().isClientSide && target instanceof LivingEntity victim) {
            level().playSound(null, blockPosition(), ModSounds.HIVE_SPAWN_ATTACK.get(),
                    SoundSource.HOSTILE, 1.0F, 1.0F);
            if (isVariantA()) {
                victim.addEffect(new net.minecraft.world.effect.MobEffectInstance(com.carnis.mod.init.ModEffects.BLEEDING.get(), 100));
                victim.addEffect(new net.minecraft.world.effect.MobEffectInstance(com.carnis.mod.init.ModEffects.VULNERABILITY.get(), 80));
            } else {
                victim.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
                heal(2.0F);
            }
        }
        return success;
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (target != null && !HiveSwarmCoordinator.validTarget(this, target)) return;
        boolean wasUntargeted = getTarget() == null;
        super.setTarget(target);
        if (wasUntargeted && target != null && !level().isClientSide) {
            level().playSound(null, blockPosition(), ModSounds.HIVE_SPAWN_ALERT.get(),
                    SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }
}
