package com.carnis.mod.client.model;

import com.carnis.mod.item.armor.FleshboundArmorItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public final class FleshboundArmorModel extends GeoModel<FleshboundArmorItem> {
    @Override public ResourceLocation getModelResource(FleshboundArmorItem item) { return new ResourceLocation("carnis", "geo/item/fleshbound_armor.geo.json"); }
    @Override public ResourceLocation getTextureResource(FleshboundArmorItem item) { return new ResourceLocation("carnis", "textures/armor/fleshbound_armor.png"); }
    @Override public ResourceLocation getAnimationResource(FleshboundArmorItem item) { return new ResourceLocation("carnis", "animations/armor/fleshbound_armor.animation.json"); }
}
