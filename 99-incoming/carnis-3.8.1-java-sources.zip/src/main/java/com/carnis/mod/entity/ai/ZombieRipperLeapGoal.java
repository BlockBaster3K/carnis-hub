package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.InfectedZombieEntity;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;

/** Variant-B leap that avoids competing with the vanilla leap used by unrelated mobs. */
public final class ZombieRipperLeapGoal extends LeapAtTargetGoal {
    private final InfectedZombieEntity zombie;
    public ZombieRipperLeapGoal(InfectedZombieEntity zombie, float leapMotionY) {
        super(zombie, leapMotionY);
        this.zombie = zombie;
    }
    @Override public boolean canUse() { return !zombie.isVariantA() && super.canUse(); }
}
