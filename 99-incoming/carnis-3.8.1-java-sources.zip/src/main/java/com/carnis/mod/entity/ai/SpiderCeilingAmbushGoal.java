package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.InfectedSpiderEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.Random;

/** Uses vanilla climbing while selecting an overhead ledge; falls back to vanilla pursuit if none is safe. */
public final class SpiderCeilingAmbushGoal extends Goal {
    private final InfectedSpiderEntity spider;
    private BlockPos perch;
    private int cooldown;

    public SpiderCeilingAmbushGoal(InfectedSpiderEntity spider) {
        this.spider = spider;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override public boolean canUse() {
        LivingEntity target = spider.getTarget();
        if (!spider.isVariantA() || target == null || !target.isAlive() || cooldown > 0) return false;
        if (spider.distanceToSqr(target) < 64.0D || spider.distanceToSqr(target) > 576.0D) return false;
        perch = findPerch(target);
        return perch != null;
    }

    @Override public boolean canContinueToUse() {
        LivingEntity target = spider.getTarget();
        return spider.isVariantA() && target != null && target.isAlive() && perch != null
                && spider.distanceToSqr(Vec3.atCenterOf(perch)) > 2.25D;
    }

    @Override public void start() { spider.getNavigation().moveTo(perch.getX() + 0.5D, perch.getY(), perch.getZ() + 0.5D, 1.15D); }
    @Override public void stop() { spider.getNavigation().stop(); perch = null; cooldown = 100; }
    @Override public void tick() { if (cooldown > 0) cooldown--; }

    private BlockPos findPerch(LivingEntity target) {
        Random random = new Random(spider.getUUID().getLeastSignificantBits() ^ spider.tickCount / 20L);
        BlockPos origin = target.blockPosition();
        for (int i = 0; i < 20; i++) {
            int dx = random.nextInt(13) - 6, dz = random.nextInt(13) - 6;
            int dy = 2 + random.nextInt(5);
            BlockPos candidate = origin.offset(dx, dy, dz);
            BlockState floor = spider.level().getBlockState(candidate.below());
            boolean support = floor.isFaceSturdy(spider.level(), candidate.below(), net.minecraft.core.Direction.UP);
            boolean clear = spider.level().isEmptyBlock(candidate) && spider.level().isEmptyBlock(candidate.above());
            double cx = candidate.getX() + 0.5D - target.getX();
            double cy = candidate.getY() + 0.5D - target.getY();
            double cz = candidate.getZ() + 0.5D - target.getZ();
            if (support && clear && cx * cx + cy * cy + cz * cz <= 225.0D
                    && spider.getSensing().hasLineOfSight(target)) return candidate;
        }
        return null;
    }
}
