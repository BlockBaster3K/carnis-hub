package com.carnis.mod.entity;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/**
 * Связывает проигрывание анимации ходьбы с фактической скоростью моба.
 *
 * Раньше контроллер движения висел на {@code state.isMoving()} — это только
 * флаг «двигается / стоит», без величины. Анимация крутилась с постоянной
 * скоростью, поэтому на быстром мобе шаг «не успевал» за перемещением.
 *
 * Здесь скорость цикла берётся из горизонтальной скорости самого моба:
 * обычная скорость ходьбы (около 0.2 блока за тик) даёт множитель 1.0,
 * быстрый бег — до 2.0. Границы не дают анимации «замереть» на месте
 * или сорваться в бешеный темп.
 */
public final class WalkAnimationSync {
    /** Обычная скорость ходьбы мобов улья — 0.2 блока за тик. */
    private static final double WALK_REFERENCE = 0.2D;
    private static final float MIN_SPEED = 0.55F;
    private static final float MAX_SPEED = 2.0F;

    private WalkAnimationSync() {
    }

    /** Множитель скорости для контроллера анимации в этот тик. */
    public static float factor(LivingEntity entity) {
        double horizontal = entity.getDeltaMovement().horizontalDistance();
        return Mth.clamp((float) (horizontal / WALK_REFERENCE), MIN_SPEED, MAX_SPEED);
    }
}
