package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.InfectedSpiderEntity;
import com.carnis.mod.init.ModEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import com.carnis.mod.init.ModBlocks;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Variant-A pounce: jumps from eight-block range or an elevated perch, then snares and paralyses nearby prey. */
public final class SpiderPounceGoal extends Goal {
    private final InfectedSpiderEntity spider;
    private int cooldown;
    private int flightTicks;
    private boolean launched;

    public SpiderPounceGoal(InfectedSpiderEntity spider) {
        this.spider = spider;
        setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP, Flag.LOOK));
    }
    @Override public boolean canUse() {
        LivingEntity target = spider.getTarget();
        if (!spider.isVariantA() || target == null || !target.isAlive() || cooldown > 0 || !spider.onGround()) return false;
        double d = spider.distanceToSqr(target);
        return d >= 9.0D && d <= 64.0D;
    }
    @Override public boolean canContinueToUse() { return launched && flightTicks < 30; }
    @Override public void start() {
        LivingEntity target = spider.getTarget();
        if (target == null) return;
        Vec3 delta = target.position().subtract(spider.position());
        Vec3 horizontal = new Vec3(delta.x, 0.0D, delta.z).normalize();
        spider.setDeltaMovement(horizontal.scale(0.85D).add(0.0D, 0.55D + Math.min(0.18D, Math.max(0.0D, delta.y * 0.04D)), 0.0D));
        spider.hasImpulse = true;
        spider.getNavigation().stop();
        launched = true;
        flightTicks = 0;
        spider.triggerCombatAnimation("pounce");
    }
    @Override public void tick() {
        if (cooldown > 0) cooldown--;
        if (!launched) return;
        flightTicks++;
        LivingEntity target = spider.getTarget();
        if (target != null && target.isAlive() && spider.distanceToSqr(target) <= 6.25D && spider.onGround() && flightTicks > 2) {
            if (spider.level() instanceof ServerLevel server) {
                target.addEffect(new MobEffectInstance(ModEffects.PARALYSIS.get(), 80, 0));
                target.addEffect(new MobEffectInstance(ModEffects.VENOM.get(), 100, 0));
                BlockPos web = target.blockPosition();
                if (server.getBlockState(web).isAir() && server.setBlock(web, ModBlocks.CARNIS_WEB.get().defaultBlockState(), 3))
                    server.scheduleTick(web, ModBlocks.CARNIS_WEB.get(), 100);
            }
            launched = false;
        }
        if (spider.onGround() && flightTicks > 2) launched = false;
    }
    @Override public void stop() {
        if (launched) cooldown = 60;
        else cooldown = 100;
        launched = false;
        flightTicks = 0;
    }
}
