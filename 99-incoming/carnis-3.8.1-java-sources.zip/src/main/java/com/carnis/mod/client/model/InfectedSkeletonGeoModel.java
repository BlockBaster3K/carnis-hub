package com.carnis.mod.client.model;

import com.carnis.mod.entity.InfectedSkeletonEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public final class InfectedSkeletonGeoModel extends GeoModel<InfectedSkeletonEntity> {
    @Override public ResourceLocation getModelResource(InfectedSkeletonEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA() ? "geo/entity/infected_skeleton.geo.json" : "geo/entity/infected_skeleton_b.geo.json");
    }
    @Override public ResourceLocation getTextureResource(InfectedSkeletonEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA() ? "textures/entity/infected_skeleton.png" : "textures/entity/infected_skeleton_b.png");
    }
    @Override public ResourceLocation getAnimationResource(InfectedSkeletonEntity entity) {
        return new ResourceLocation("carnis", entity.isVariantA() ? "animations/entity/infected_skeleton.animation.json" : "animations/entity/infected_skeleton_b.animation.json");
    }
}
