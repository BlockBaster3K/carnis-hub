package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.InfectedZombieEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Scythed Stalker: slow 3.5-block frontal cleave, enabled only for variant A. */
public final class ZombieScytheCleaveGoal extends Goal {
    private static final double REACH = 3.5D;
    private static final int ATTACK_INTERVAL_TICKS = 24; // 20% slower than the 20-tick baseline.
    private final InfectedZombieEntity zombie;
    private int attackCooldown;

    public ZombieScytheCleaveGoal(InfectedZombieEntity zombie) {
        this.zombie = zombie;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = zombie.getTarget();
        return zombie.isVariantA() && target != null && target.isAlive()
                && HiveSwarmCoordinator.validTarget(zombie, target);
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        attackCooldown = 0;
    }

    @Override
    public void stop() {
        zombie.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity primary = zombie.getTarget();
        if (primary == null || !primary.isAlive()) return;
        zombie.getLookControl().setLookAt(primary, 30.0F, 30.0F);
        double reachWithWidth = REACH + primary.getBbWidth() * 0.5D;
        if (zombie.distanceToSqr(primary) > reachWithWidth * reachWithWidth) {
            zombie.getNavigation().moveTo(primary, 1.0D);
        } else {
            zombie.getNavigation().stop();
        }
        if (attackCooldown > 0) attackCooldown--;
        if (attackCooldown > 0 || zombie.distanceToSqr(primary) > reachWithWidth * reachWithWidth
                || !zombie.hasLineOfSight(primary)) return;

        attackCooldown = ATTACK_INTERVAL_TICKS;
        zombie.triggerAnim("action", "scythe_cleave");
        zombie.swing(InteractionHand.MAIN_HAND);
        Vec3 look = zombie.getLookAngle();
        Vec3 forward = new Vec3(look.x, 0.0D, look.z);
        if (forward.lengthSqr() < 1.0E-8D) {
            double yaw = Math.toRadians(zombie.getYRot());
            forward = new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
        } else {
            forward = forward.normalize();
        }
        AABB area = zombie.getBoundingBox().inflate(REACH, 1.0D, REACH);
        for (LivingEntity victim : zombie.level().getEntitiesOfClass(LivingEntity.class, area,
                candidate -> candidate != zombie && candidate.isAlive()
                        && HiveSwarmCoordinator.validTarget(zombie, candidate)
                        && zombie.distanceToSqr(candidate) <= Math.pow(REACH + candidate.getBbWidth() * 0.5D, 2.0D)
                        && zombie.hasLineOfSight(candidate))) {
            Vec3 offset = victim.position().subtract(zombie.position());
            Vec3 horizontal = new Vec3(offset.x, 0.0D, offset.z);
            if (horizontal.lengthSqr() > 1.0E-8D && forward.dot(horizontal.normalize()) < 0.15D) continue;
            zombie.doHurtTarget(victim);
        }
    }
}
