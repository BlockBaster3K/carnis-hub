package com.carnis.mod.entity.ai;

import com.carnis.mod.entity.InfectedZombieEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/** Fast 10-tick bite loop reserved for Split-Jaw Ripper variant B. */
public final class VariantMeleeAttackGoal extends Goal {
    private final InfectedZombieEntity zombie;
    private int biteCooldown;
    public VariantMeleeAttackGoal(InfectedZombieEntity zombie, double speed) {
        this.zombie = zombie;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }
    @Override public boolean canUse() {
        LivingEntity target = zombie.getTarget();
        return !zombie.isVariantA() && target != null && target.isAlive()
                && HiveSwarmCoordinator.validTarget(zombie, target);
    }
    @Override public boolean canContinueToUse() { return canUse(); }
    @Override public void start() { biteCooldown = 0; }
    @Override public void stop() { zombie.getNavigation().stop(); }
    @Override public void tick() {
        LivingEntity target = zombie.getTarget();
        if (target == null || !target.isAlive()) return;
        zombie.getLookControl().setLookAt(target, 30.0F, 30.0F);
        zombie.getNavigation().moveTo(target, 1.0D);
        if (biteCooldown > 0) biteCooldown--;
        double reach = 2.0D + target.getBbWidth() * 0.5D;
        if (biteCooldown == 0 && zombie.distanceToSqr(target) <= reach * reach
                && zombie.hasLineOfSight(target)) {
            zombie.swing(InteractionHand.MAIN_HAND);
            zombie.doHurtTarget(target);
            biteCooldown = 10;
        }
    }
}
