package com.carnis.mod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Temporary Carnis-grown snare left by the Raptorial Arachnid pounce.
 *
 * Snare behaviour comes from this block's own physics callback instead of
 * inheriting CobwebBlock: CobwebBlock is final in 1.20.1, so it cannot be
 * specialised. Extending plain Block keeps the intended gameplay effect and
 * adds the part CobwebBlock never had — the snare expires by itself.
 *
 * Expiry uses the scheduled-tick pattern the other Carnis blocks already use
 * (see IncubationCystBlock): onPlace schedules ONE tick LIFETIME_TICKS ahead,
 * and that tick removes the block. One scheduled tick is enough, so no counter
 * or block entity is needed. randomTick is a safety net for chunks that unload
 * before the scheduled tick fires, and isRandomlyTicking turns it on.
 */
public final class CarnisWebBlock extends Block {
    /** How long the snare stays before it dissolves: 8 s. */
    private static final int LIFETIME_TICKS = 160;

    public CarnisWebBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moving) {
        super.onPlace(state, level, pos, oldState, moving);
        if (!level.isClientSide && !state.is(oldState.getBlock())) {
            level.scheduleTick(pos, this, LIFETIME_TICKS);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (level.getBlockState(pos).is(this)) level.removeBlock(pos, false);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (level.getBlockState(pos).is(this)) level.removeBlock(pos, false);
    }

    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return true;
    }

    /** The snare drags entities down to a crawl; it does not immobilise them. */
    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        entity.makeStuckInBlock(state, new Vec3(0.25D, 0.05D, 0.25D));
    }
}
