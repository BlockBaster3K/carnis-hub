# Effect icons · 3.5.2-R base · review submission

Два НОВЫХ RGBA PNG 18×18; базовые файлы отсутствуют, старый SHA и количество изменённых пикселей неприменимы.
Не установлены в проект. Ожидается включение Кодером в следующий согласованный пакет; наличие в 04-artist не меняет JAR.
Ревизия, игровой HUD и автоматическая загрузка не проверены. 3.5.1 остаётся замороженным.

src/main/resources/assets/carnis/textures/mob_effect/incubating.png | e4dd9bd7371995f9833e2ac30af63b09e4282ac35e12e4be4d926ccfef2e43a8 | 18x18 RGBA | 320 bytes | alpha 0/255
src/main/resources/assets/carnis/textures/mob_effect/thermal_shock.png | ffb30371f5047a87605f0d1df433df7c8d5450b3f7bcd7ed655b09c9e9023c13 | 18x18 RGBA | 346 bytes | alpha 0/255
