package com.carnis.mod.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;

/** Arrow shell whose small bonus hit uses magic damage to partially bypass armor, as requested for the sniper variant. */
public final class CarnisPiercingArrow extends Arrow {
    private final float armorPiercingBonus;
    public CarnisPiercingArrow(Level level, LivingEntity owner, float armorPiercingBonus) {
        super(level, owner);
        this.armorPiercingBonus = Math.max(0.0F, armorPiercingBonus);
    }
    @Override protected void onHitEntity(EntityHitResult hit) {
        super.onHitEntity(hit);
        if (armorPiercingBonus > 0.0F && hit.getEntity() instanceof LivingEntity living
                && !level().isClientSide && living.isAlive()) {
            living.hurt(level().damageSources().magic(), armorPiercingBonus);
        }
    }
}
