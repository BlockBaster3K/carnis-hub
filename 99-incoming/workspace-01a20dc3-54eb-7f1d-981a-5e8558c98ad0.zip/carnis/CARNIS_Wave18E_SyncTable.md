# CARNIS · Сводная таблица синхронизации (единый документ к сдаче, волна 18E)

**Банк после 18E:** 157 OGG / 12 061 409 Б · манифест 158 строк (157 + заголовок) · расхождений манифест↔диск **0** · формат vorbis/44100/mono **157/157** · битрейт 160 — 80 файлов, 96 — 77 (долг волн 1–17, перекодировка не санкционирована).

**Пакет:** `transfer/CARNIS_transfer_105.tar.gz` — 105 файлов, 10 850 737 Б распакованных, размер архива 10 448 216 Б. SHA256 в архиве == SHA256 на диске: **105/105**. Суммы: `transfer/SHA256SUMS_transfer105.txt` (105 строк, flat).

> ## ⛔ АКТУАЛЬНО (22.11, Волна 21) — читать до всего остального
>
> **План §2.1–2.4 НЕ К ИСПОЛНЕНИЮ.** Его заменил указ на 142 файла:
> **копировать всё из `assets/carnis/sounds/`, кроме `*_w1516.ogg` (14) и `block/heart_pulse.ogg`, без удалений.**
> Ожидаемый итог: **142 файла** банка + **2 legacy** (`entity/flesh_amalgam_death`, `entity/flesh_amalgam_hurt`), которые остаются на месте до 3.5.2; `heart_pulse` остаётся проектной версией → в проекте **145** (142 + 1 + 2).
> Числа остатка §3: **12 затёрто / 1 остаётся проектной / 11 восстанавливаются**.
> Всё, что ниже (включая «удалить 10», «перезаписать 14», «разместить 85», «остаток 52»), — **история волны 18E**. Она сохранена как есть, расхождения разобраны в разделе **§4 «Поправки по ревизии 18E»** в конце документа.

---

## 1. Прежний пакет 86 был неполным — подтверждаю проверкой

Содержимое `CARNIS_transfer_86.tar.gz`, проверенное по составу архива:

| Позиция | В пакете 86 |
|---|---|
| 74 ранее переданных | есть |
| 12 файлов 18D §3 | есть |
| 10 недостающих из «14 перезаписей» (breath_01/02, shuffle_03, crawl_01/02, detonate_01/02, sac_01/02/03) | **нет** |
| 3 файла класса A (18D §4) | **нет** |
| 6 файлов 18E | **нет** |

Итого дополнено **19** файлов → **74 + 12 + 19 = 105**. Ваша догадка («если 86 = 74+12, пакет неполный») подтвердилась полностью.

---
## 2. Итоговая таблица по проекту

### 2.0 Три числа, которые надо держать вместе

| Действие | Файлов | Байт |
|---|---|---|
| **РАЗМЕСТИТЬ новое** (в проекте нет вообще) | **85** | 10 475 797 |
| **ПЕРЕЗАПИСАТЬ** (в проекте лежит старое по тому же пути) | **14** | 325 730 |
| **ПЕРЕМЕСТИТЬ** (в проекте лежит по старому пути) | **10** | 85 641 |
| **УДАЛИТЬ** (кодеровские, после прихода замен) | **10** | — |
| сумма копирования = пакет | **105** | 10 850 737 |

85 + 14 + 6 = 105: из 10 «перемещений» четыре (`hive_spawn_hurt_critical_01…04`) уже стоят в проекте под новыми именами, поэтому физически копируются только 6 файлов `block/*`.

### 2.1 РАЗМЕСТИТЬ новое — 85 файлов

| # | Путь в проекте | Байт | Группа |
|---|---|---|---|
| 1 | `amb/hive_ambient_01.ogg` | 970994 | амбиенты улья |
| 2 | `amb/hive_ambient_02.ogg` | 965598 | амбиенты улья |
| 3 | `amb/hive_ambient_03.ogg` | 970454 | амбиенты улья |
| 4 | `amb/hive_ambient_close_01.ogg` | 1068391 | амбиенты улья |
| 5 | `amb/hive_ambient_close_02.ogg` | 977381 | амбиенты улья |
| 6 | `amb/hive_ambient_tonal_stinger.ogg` | 83761 | амбиенты улья |
| 7 | `amb/hive_pulse_01.ogg` | 98999 | амбиенты улья |
| 8 | `amb/hive_pulse_02.ogg` | 98907 | амбиенты улья |
| 9 | `amb/hive_pulse_03.ogg` | 98576 | амбиенты улья |
| 10 | `block/bone_deflect.ogg` | 10767 | блоки |
| 11 | `block/creeper_rupture.ogg` | 16898 | блоки |
| 12 | `block/hive_membrane_place_01.ogg` | 10556 | блоки |
| 13 | `block/hive_membrane_step_01.ogg` | 12458 | блоки |
| 14 | `block/synapse_node_pulse_01.ogg` | 26700 | блоки |
| 15 | `block/synapse_shock.ogg` | 13424 | блоки |
| 16 | `combat/combat_deflect_01_chitin.ogg` | 5641 | бой |
| 17 | `combat/combat_deflect_02_bone.ogg` | 5417 | бой |
| 18 | `combat/combat_deflect_03_metal.ogg` | 4760 | бой |
| 19 | `combat/combat_deflect_04_glance.ogg` | 6138 | бой |
| 20 | `combat/combat_deflect_05_parry.ogg` | 5615 | бой |
| 21 | `combat/combat_flesh_hit_01.ogg` | 9490 | бой |
| 22 | `combat/combat_flesh_hit_02.ogg` | 10534 | бой |
| 23 | `combat/combat_flesh_hit_03.ogg` | 8490 | бой |
| 24 | `combat/combat_flesh_hit_deep_01_axe.ogg` | 11116 | бой |
| 25 | `combat/combat_flesh_hit_deep_02_crit.ogg` | 9867 | бой |
| 26 | `combat/combat_flesh_hit_deep_03_blast.ogg` | 12007 | бой |
| 27 | `combat/combat_stab_01_bone.ogg` | 5943 | бой |
| 28 | `combat/combat_stab_02_chitin.ogg` | 5232 | бой |
| 29 | `combat/combat_stab_03_shield.ogg` | 5447 | бой |
| 30 | `combat/dismember_01.ogg` | 15706 | бой |
| 31 | `combat/dismember_02.ogg` | 14863 | бой |
| 32 | `combat/dismember_03.ogg` | 16638 | бой |
| 33 | `combat/dismember_04.ogg` | 12415 | бой |
| 34 | `combat/dismember_05.ogg` | 16827 | бой |
| 35 | `combat/ossified_scythe_hit_01.ogg` | 13163 | бой |
| 36 | `combat/ossified_scythe_swing_01.ogg` | 16267 | бой |
| 37 | `entity/flamethrower_fire.ogg` | 28688 | сущности |
| 38 | `entity/flesh_amalgam_death_01.ogg` | 43857 | сущности |
| 39 | `entity/flesh_amalgam_hurt_01.ogg` | 23888 | сущности |
| 40 | `entity/flesh_amalgam_roar_01.ogg` | 31238 | сущности |
| 41 | `entity/flesh_amalgam_roar_02.ogg` | 19726 | сущности |
| 42 | `entity/flesh_amalgam_smash_01.ogg` | 24183 | сущности |
| 43 | `entity/flesh_amalgam_smash_02.ogg` | 23817 | сущности |
| 44 | `entity/flesh_amalgam_step_01.ogg` | 20741 | сущности |
| 45 | `entity/flesh_amalgam_step_02.ogg` | 15204 | сущности |
| 46 | `entity/incubation_cyst_ambient_01.ogg` | 32621 | сущности |
| 47 | `entity/incubation_cyst_rupture_01.ogg` | 17373 | сущности |
| 48 | `entity/organic_creak.ogg` | 24038 | сущности |
| 49 | `entity/pustule_grenade_impact_01.ogg` | 19194 | сущности |
| 50 | `entity/pustule_grenade_throw_01.ogg` | 13683 | сущности |
| 51 | `entity/sinew_shield_block_01.ogg` | 11958 | сущности |
| 52 | `flesh/flesh_block_step_01.ogg` | 7767 | плоть |
| 53 | `flesh/flesh_block_step_02.ogg` | 7908 | плоть |
| 54 | `flesh/flesh_block_step_03.ogg` | 7146 | плоть |
| 55 | `hallucination/phantom_creeper.ogg` | 37850 | галлюцинации |
| 56 | `hallucination/phantom_whisper.ogg` | 32398 | галлюцинации |
| 57 | `hive/amb_core.ogg` | 1046279 | улей |
| 58 | `hive/amb_deep.ogg` | 913230 | улей |
| 59 | `hive/amb_surface.ogg` | 1041842 | улей |
| 60 | `hive/amb_threshold.ogg` | 1029799 | улей |
| 61 | `hive/detail_bubbles_01.ogg` | 10930 | улей |
| 62 | `hive/detail_creak_01.ogg` | 14453 | улей |
| 63 | `hive/detail_flow_01.ogg` | 16071 | улей |
| 64 | `hive/detail_flow_02.ogg` | 8341 | улей |
| 65 | `hive/detail_membrane_01.ogg` | 9436 | улей |
| 66 | `hive/detail_scuttle_01.ogg` | 10438 | улей |
| 67 | `hive/hive_spawn_attack_01.ogg` | 7188 | улей |
| 68 | `hive/hive_spawn_attack_02.ogg` | 8242 | улей |
| 69 | `hive/hive_spawn_attack_03.ogg` | 9495 | улей |
| 70 | `hive/hive_spawn_attack_04.ogg` | 10533 | улей |
| 71 | `hive/hive_spread_01_creep.ogg` | 6167 | улей |
| 72 | `hive/hive_spread_02_pulse.ogg` | 9150 | улей |
| 73 | `hive/hive_spread_03_swell.ogg` | 12779 | улей |
| 74 | `hive/spawn_skeleton_blade_01.ogg` | 15245 | улей |
| 75 | `hive/spawn_skeleton_blade_02.ogg` | 18133 | улей |
| 76 | `hive/spawn_skeleton_blade_03.ogg` | 13665 | улей |
| 77 | `hive/zone_stinger_deep.ogg` | 22938 | улей |
| 78 | `hive/zone_stinger_intensify.ogg` | 19526 | улей |
| 79 | `hive/zone_stinger_release.ogg` | 14075 | улей |
| 80 | `item/dart_hit.ogg` | 11504 | предметы |
| 81 | `item/inoculator_fire.ogg` | 10490 | предметы |
| 82 | `item/purification_vial_break_01.ogg` | 14939 | предметы |
| 83 | `item/purifier_ignite.ogg` | 19819 | предметы |
| 84 | `item/purifier_lamp_ignite_01.ogg` | 25511 | предметы |
| 85 | `item/purifier_loop.ogg` | 46861 | предметы |

Итого **85** файлов  10 475 797 Б.

### 2.2 ПЕРЕЗАПИСАТЬ — 14 файлов (старые волны 15/16 → архив 18A)

| # | Путь | старый размер | новый размер | Δ |
|---|---|---|---|---|
| 1 | `hive/amalgam_breath_01.ogg` | 38235 | 38924 | +689 |
| 2 | `hive/amalgam_breath_02.ogg` | 38790 | 47090 | +8300 |
| 3 | `hive/amalgam_shuffle_01.ogg` | 44121 | 21534 | -22587 |
| 4 | `hive/amalgam_shuffle_02.ogg` | 44054 | 24032 | -20022 |
| 5 | `hive/amalgam_shuffle_03.ogg` | 34281 | 19130 | -15151 |
| 6 | `hive/amalgam_slam_01.ogg` | 18436 | 27556 | +9120 |
| 7 | `hive/amalgam_slam_02.ogg` | 17363 | 24605 | +7242 |
| 8 | `hive/spawn_creeper_crawl_01.ogg` | 22169 | 19662 | -2507 |
| 9 | `hive/spawn_creeper_crawl_02.ogg` | 25602 | 21906 | -3696 |
| 10 | `hive/spawn_creeper_detonate_01.ogg` | 37264 | 12919 | -24345 |
| 11 | `hive/spawn_creeper_detonate_02.ogg` | 23551 | 11723 | -11828 |
| 12 | `hive/spawn_creeper_sac_01.ogg` | 19563 | 18010 | -1553 |
| 13 | `hive/spawn_creeper_sac_02.ogg` | 22447 | 15793 | -6654 |
| 14 | `hive/spawn_creeper_sac_03.ogg` | 21073 | 22846 | +1773 |

### 2.3 ПЕРЕМЕСТИТЬ — 10 файлов

| # | из | в | байт | уже в проекте? |
|---|---|---|---|---|
| 1 | `hive/hive_block_break_01_tear.ogg` | `block/hive_block_break_01_tear.ogg` | 9890 | нет, скопировать |
| 2 | `hive/hive_block_break_02_pop.ogg` | `block/hive_block_break_02_pop.ogg` | 10439 | нет, скопировать |
| 3 | `hive/hive_block_break_03_crunch.ogg` | `block/hive_block_break_03_crunch.ogg` | 11526 | нет, скопировать |
| 4 | `hive/hive_block_place_01_soft.ogg` | `block/hive_block_place_01_soft.ogg` | 5965 | нет, скопировать |
| 5 | `hive/hive_block_place_02_dense.ogg` | `block/hive_block_place_02_dense.ogg` | 5667 | нет, скопировать |
| 6 | `hive/hive_block_place_03_wet.ogg` | `block/hive_block_place_03_wet.ogg` | 5723 | нет, скопировать |
| 7 | `hive/spawn_hurt_critical_01.ogg` | `hive/hive_spawn_hurt_critical_01.ogg` | 9938 | да, только проверить SHA256 |
| 8 | `hive/spawn_hurt_critical_02.ogg` | `hive/hive_spawn_hurt_critical_02.ogg` | 8267 | да, только проверить SHA256 |
| 9 | `hive/spawn_hurt_critical_03.ogg` | `hive/hive_spawn_hurt_critical_03.ogg` | 8898 | да, только проверить SHA256 |
| 10 | `hive/spawn_hurt_critical_04.ogg` | `hive/hive_spawn_hurt_critical_04.ogg` | 9328 | да, только проверить SHA256 |

### 2.4 УДАЛИТЬ — 10 кодеровских (только после прихода замен)

| # | Путь в проекте | чем закрывается |
|---|---|---|
| 1 | `entity/creeper_rupture.ogg` | `block/creeper_rupture.ogg` (разместить, §2.1) |
| 2 | `entity/flamethrower_fire.ogg` | `entity/flamethrower_fire.ogg` — **тот же путь**, замена файла (18D → 18E, переименование по п.1) |
| 3 | `entity/flesh_amalgam_death.ogg` | `entity/flesh_amalgam_death_01.ogg` — носитель событий **самой амальгамы**; plain-файл теряет пользователей и удаляется (смыслы не объединяем) |
| 4 | `entity/flesh_amalgam_hurt.ogg` | `entity/flesh_amalgam_hurt_01.ogg` — носитель событий **самой амальгамы**; plain-файл теряет пользователей и удаляется (смыслы не объединяем) |
| 5 | `hallucination/phantom_creeper.ogg` | замена файла по тому же пути (§2.1) |
| 6 | `hallucination/phantom_whisper.ogg` | замена файла по тому же пути (§2.1) |
| 7 | `item/dart_hit.ogg` | замена файла по тому же пути (§2.1) |
| 8 | `item/inoculator_fire.ogg` | замена файла по тому же пути (§2.1) |
| 9 | `item/purifier_ignite.ogg` | замена файла по тому же пути (§2.1) |
| 10 | `item/purifier_loop.ogg` | замена файла по тому же пути (§2.1) |

**Порядок важен:** сначала положить замену, потом удалять старое. Для 6 позиций (`phantom_*`, `dart_hit`, `inoculator_fire`, `purifier_ignite`, `purifier_loop`) путь совпадает — это перезапись, а не удаление; удаление касается только `entity/creeper_rupture`, `entity/flamethrower_fire` (старое имя `item/flamethrower_fire`), `entity/flesh_amalgam_death`, `entity/flesh_amalgam_hurt`. **Уточнение (решение Архитектора):** `hive.spawn_death|hurt|hurt_critical` остаются на семействах Улья (12 файлов), амальгамные `_01` — только на событиях амальгамы; переадресации нет.

---
## 3. Остаток банка, ещё не размещённый

Всего в банке **157**, в пакете 18E **105**, **остаток 52** — по трём причинам: архив, файл вне событий, размещено ранее.

| группа | файлов |
|---|---|
| архив `*_w1516` — **не переносить** | 14 |
| сирота: файл вне событий `sounds.json` | 1 |
| размещено в проекте ранее (волны 2–18C) | 37 |
| **проверка** | **14 + 1 + 37 = 52** ✔ |

### 3.1 Поправка А (опечатка 18E, внесена в волне 19)

В таблице стояло «сироты — 1», а список ниже был озаглавлен «Сироты — 8», и в него были подмешаны 7 файлов `flesh_amalgam_*`, которые входят в пакет 105 (§2.1) и сиротами не являются. Действительная картина: **сирота один — `entity/flesh_amalgam_ambient`**. Список исправлен ниже.

### 3.2 Поправка Б — затёртые zip-синком: единое число **12 / 1 / 11**

**Затёрто 12 файлов. 1 остаётся проектной версией, 11 восстанавливаются из банка.** Число согласовано с координатором (Волна 20, п.3).

| № | файл | Решение | Обоснование |
|---|---|---|---|
| 1 | `block/heart_pulse.ogg` | **остаётся проектная версия** (0.62 с / 24 кГц) | озвучивает сам блок сердца: `pulsing_heart_beat` → `PulsingHeartBlockEntity`; плюс `FleshBulbBlockEntity` (фаза 0) |
| 2 | `block/heartbeat_loop.ogg` | из банка (1.94 с / 44.1 кГц) | не сердце блока: `HeartAmbientTicker`, `PlayerHallucinationHandler` (2 места), `HiveAmbientSoundHandler` (2 места) |
| 3 | `block/hive_heartbeat.ogg` | из банка (2.34 с / 44.1 кГц) | не сердце блока: `HiveAmbientSoundHandler`, сердцебиение ульевой ткани |
| 4 | `block/digestor_churn.ogg` | из банка | — |
| 5 | `block/hive_alarm.ogg` | из банка | — |
| 6 | `block/hive_eye_screech.ogg` | из банка | — |
| 7 | `block/nervous_twitch.ogg` | из банка | — |
| 8 | `block/pustule_burst.ogg` | из банка | — |
| 9 | `block/synapse_rupture.ogg` | из банка | — |
| 10 | `entity/acid_splash.ogg` | из банка | — |
| 11 | `entity/amalgamation_fuse.ogg` | из банка | — |
| 12 | `entity/flesh_amalgam_ambient.ogg` | из банка | — |

**Что это меняет в объёме копирования:** все 12 входят в `transfer/PACKAGE_105.txt`, но №1 копировать нельзя. Итог Волны 20 — **157 − 14 − 1 = 142 файла**.

> ⚠️ **Исключение должно быть явным в скрипте копирования.** Правило «всё, кроме `*_w1516`» затрёт сердце заказчика второй раз. Правило: «всё, кроме `*_w1516` **и** `block/heart_pulse.ogg`».

> ⚠️ **Про путь `03-sound/sounds/` из указания Волны 20:** у меня такого пути нет. Источник истины — `assets/carnis/sounds/` (157 / 12 061 409 Б, сверено). Если `03-sound/sounds/` — рабочая копия заказчика, она источником истины не является и воркспейс не подменяет.

> ⚠️ **Уточнение к списку «удалить 12» из указания Волны 20 (проверено по банку):**
> 1. **Мой банк — источник, а не цель.** Все 12 указанных позиций **есть в банке** (`hive/hive_block_break_01…03`, `hive/hive_block_place_01…03`, `hive/hive_spawn_hurt_critical_01…04`, `entity/flesh_amalgam_death.ogg`, `entity/flesh_amalgam_hurt.ogg`). Если их удалить из проекта вручную, они вернутся при копировании 142 файлов. Удалять их **не нужно** — достаточно не копировать: в наборе 142 их нет по построению.
> 2. **Счёт 6 + 4 + 2 = 12 верен, но имена двух последних надо произнести точно.** В банке амальгамные файлы лежат как **`_01`** (носители событий амальгамы по решению 18E): `entity/flesh_amalgam_death_01.ogg`, `entity/flesh_amalgam_hurt_01.ogg`. Удалению из проекта подлежат **plain-версии без суффикса** — `entity/flesh_amalgam_death.ogg` и `entity/flesh_amalgam_hurt.ogg`, **без переадресации**. Файлы `_01` — рабочие, их не трогать.
> 3. **Дубли блобов подтверждаю цифрами, но это не побайтовые дубли:** `synapse_rupture ↔ nervous_twitch` корреляция огибающих 0.972, `pustule_burst ↔ acid_splash` 0.874, `synapse_rupture ↔ creeper_rupture` 0.874, `hive_alarm ↔ hive_eye_screech` 0.388 (слышимая разница есть: 1.55 с / 1595 Гц против 1.90 с / 1756 Гц, crest 14.1 / 12.9). Все три версии в наборе 142 приезжают из банка, поэтому «вылечиваются» они самим копированием, а не правкой файлов. Разведение — задача после теста, не сейчас.

**Архив — 14:**
- `hive/amalgam_breath_01_w1516.ogg`
- `hive/amalgam_breath_02_w1516.ogg`
- `hive/amalgam_shuffle_01_w1516.ogg`
- `hive/amalgam_shuffle_02_w1516.ogg`
- `hive/amalgam_shuffle_03_w1516.ogg`
- `hive/amalgam_slam_01_w1516.ogg`
- `hive/amalgam_slam_02_w1516.ogg`
- `hive/spawn_creeper_crawl_01_w1516.ogg`
- `hive/spawn_creeper_crawl_02_w1516.ogg`
- `hive/spawn_creeper_detonate_01_w1516.ogg`
- `hive/spawn_creeper_detonate_02_w1516.ogg`
- `hive/spawn_creeper_sac_01_w1516.ogg`
- `hive/spawn_creeper_sac_02_w1516.ogg`
- `hive/spawn_creeper_sac_03_w1516.ogg`

**Сирота — 1** (события нет в реестре 3.4.5; не объявлять, не удалять):
- ⚠ `entity/flesh_amalgam_ambient.ogg` (затёрт zip-синком, восстановится из банка)

**Размещено ранее — 37** (⚠ = затёрт zip-синком; из 12 затёртых один, `heart_pulse`, не восстанавливать):
- ⚠ `block/digestor_churn.ogg` (затёрт zip-синком)
- ⚠ `block/heart_pulse.ogg` (остаётся проектная версия)
- ⚠ `block/heartbeat_loop.ogg` (затёрт zip-синком)
- ⚠ `block/hive_alarm.ogg` (затёрт zip-синком)
- ⚠ `block/hive_eye_screech.ogg` (затёрт zip-синком)
- ⚠ `block/hive_heartbeat.ogg` (затёрт zip-синком)
- ⚠ `block/nervous_twitch.ogg` (затёрт zip-синком)
- ⚠ `block/pustule_burst.ogg` (затёрт zip-синком)
- ⚠ `block/synapse_rupture.ogg` (затёрт zip-синком)
- ⚠ `entity/acid_splash.ogg` (затёрт zip-синком)
- ⚠ `entity/amalgamation_fuse.ogg` (затёрт zip-синком)
- `hallucination/phantom_footsteps.ogg`
- `hive/hive_spawn_alert_01.ogg`
- `hive/hive_spawn_alert_02.ogg`
- `hive/hive_spawn_alert_03.ogg`
- `hive/hive_spawn_alert_04.ogg`
- `hive/hive_spawn_death_01.ogg`
- `hive/hive_spawn_death_02.ogg`
- `hive/hive_spawn_death_03.ogg`
- `hive/hive_spawn_death_04.ogg`
- `hive/hive_spawn_hurt_01.ogg`
- `hive/hive_spawn_hurt_02.ogg`
- `hive/hive_spawn_hurt_03.ogg`
- `hive/hive_spawn_hurt_04.ogg`
- `hive/hive_spawn_hurt_critical_01.ogg`
- `hive/hive_spawn_hurt_critical_02.ogg`
- `hive/hive_spawn_hurt_critical_03.ogg`
- `hive/hive_spawn_hurt_critical_04.ogg`
- `hive/hive_spawn_idle_01.ogg`
- `hive/hive_spawn_idle_02.ogg`
- `hive/hive_spawn_idle_03.ogg`
- `hive/hive_spawn_idle_04.ogg`
- `hive/spawn_skeleton_bonecrack_01.ogg`
- `hive/spawn_skeleton_bonecrack_02.ogg`
- `hive/spawn_skeleton_whip_01.ogg`
- `hive/spawn_skeleton_whip_02.ogg`
- `hive/spawn_skeleton_whip_03.ogg`

---

## 4. Поправки по ревизии 18E (внесены в Волне 21)

История выше **не переписана** — старые числа оставлены как были. Здесь то, что ревизия признала неверным, с фактическим состоянием на 22.11.

| # | Блокер / замечание | Что было в 18E | Факт | Как исправлено |
|---|---|---|---|---|
| **B1** | 26 файлов вне пакета | утверждалось, что пакет 105 покрывает всё нужное | **Факт: пакет 105 не покрывал 26 позиций** — 12 флагов §2.3/§2.4, 6 файлов 18E и 8 алиасов Q7 не имели в пакете явного пути. Проверено по `transfer/PACKAGE_105.txt` / `SHA256SUMS_transfer105.txt` | заменено указом на **142** (`transfer/PACKAGE_142.txt`, `SHA256SUMS_transfer142.txt`, 142/142) — покрытие полное по построению: копируется весь банк |
| **B2** | противоречие `flamethrower_fire` | в §2.1 путь `entity/flamethrower_fire.ogg`, в §2.4 «удалить `entity/flamethrower_fire.ogg`, старое имя `item/flamethrower_fire`» — то есть удалить тот же путь, который только что размещён | **Противоречие реальное.** Файл один: `entity/flamethrower_fire.ogg` (28 688 Б, луп, 1.64 с), в банке существует только под `entity/` | при копировании 142 он перезаписывается по своему единственному пути; **удалять нечего** — правила «удалять» больше нет |
| **B3** | два события без носителей | §2.4 предписывал удалить `entity/flesh_amalgam_death` и `entity/flesh_amalgam_hurt`, хотя `sounds.json` ссылается именно на эти пути, а в банке они есть только как `_01` | **Подтверждаю: удаление сделало бы два события тишиной.** Мой прежний вывод «plain теряет пользователей → удаляется» опирался на решение «смыслы не объединяем», но не учитывал, что объявление на эти пути существует | **удаление отменено полностью.** Оба legacy-файла остаются до 3.5.2, пока Кодер не переведёт события на `_01`. В наборе 142 их нет — значит копирование их не тронет |
| **M2** | «перезаписать 14» | 14 позиций §2.2 | **Факт: 0 из 14 в проекте не перезаписываются как «14»** — из них 10 отсутствуют в проекте вовсе (затёрты zip-синком), 4 совпадают по пути с уже размещёнными; фактических перезаписей при копировании 142 — столько, сколько путей пересечётся, и это проверяется счётом, а не планом | снято вместе с §2.1–2.4 |
| **M4** | «размещено ранее 37» | 37 позиций | **Факт: целых 26 из 37**, затёрто 11 (двенадцатое затёртое, `heart_pulse`, вынесено в «остаётся проектной версией»). Сверено по `PACKAGE_105.txt`: 14 архив + 1 сирота + 11 затёртых + 26 целых = **52** ✔. Отдельно считать «37 целых» нельзя: в проекте 26 | в §3.2 таблица 12 / 1 / 11; сводка остатка в §4.1 ниже |
| **M6** | «сироты 8» при одной позиции | список озаглавлен «Сироты — 8», в таблице 1 | **Факт: сирота один** — `entity/flesh_amalgam_ambient`. Семь `flesh_amalgam_*` в пакете 105, сиротами не являются | исправлено в §3.1 (Волна 19) |
| **M7** | `STATUS` устарел | — | факт **157 / 12 061 409 Б**; устаревшее 136 / 11 629 054 = состояние до 18D (+15) и 18E (+6) | блок статуса в `CARNIS_Wave20_RepoDelivery.md` §3 — вставить как есть |
| — | `03-sound/sounds/` как источник | путь фигурировал в указаниях | **такого пути в воркспейсе нет**; источник истины — `assets/carnis/sounds/` | исправлено координатором в Волне 21 |
| **M8** | счёт в проекте после синхронизации | в Волне 21 у меня стояло «144 = 142 + 2 legacy» | **Факт: 145** = 142 банковских + 1 `block/heart_pulse.ogg` (проектная версия, не копируется, но и не исчезает) + 2 legacy. Мои 144 — артефакт сухой фикстуры без сердца | скрипт `transfer/sync_142.sh` теперь требует наличие `heart_pulse` и падает с кодом 3, если его нет |

### 4.1 Сводка остатка на 22.11 (после снятия §2.1–2.4)

| группа | файлов | что с ними |
|---|---|---|
| копируется в проект | **142** | весь банк минус архив и `block/heart_pulse.ogg` |
| архив `*_w1516` | 14 | не копировать |
| остаётся проектной версией | 1 | `block/heart_pulse.ogg` (0.62 с / 24 кГц) |
| **итого банк** | **157** | 142 + 14 + 1 ✔ |
| legacy в проекте, не трогать до 3.5.2 | 2 | `entity/flesh_amalgam_death.ogg`, `entity/flesh_amalgam_hurt.ogg` |

**Проверка после синхронизации:** `142 банковских + 1 heart_pulse (проектная версия) + 2 legacy = 145` `.ogg` в каталоге проекта.

Разложение остатка 52 (сверено по `PACKAGE_105.txt`): 14 архив + 1 сирота (= `flesh_amalgam_ambient`, он же 12-е затёртое) + 11 затёртых (восстанавливаются) + 26 целых = 52 ✔.

Сверка с указом на 142: все 142 файла набора — это пакет 105 **минус** `block/heart_pulse.ogg` **плюс** 38 позиций остатка, из которых 11 затёртых берутся из банка, а 26 целых и так на месте и просто перезаписываются теми же байтами (SHA256 в `SHA256SUMS_transfer142.txt` = SHA256 на диске 142/142). Архив 14 и `heart_pulse` в набор не входят.

### 4.2 Чего в банке нет вовсе (проверено 22.11)

Позиции из указаний прошлых волн, которых в банке **не существует под этими именами** — при копировании они не появятся, и это надо знать до теста, чтобы не искать «пропажу»:

| имя из документов | фактическое состояние |
|---|---|
| `entity/creeper_rupture.ogg` | в банке лежит как **`block/creeper_rupture.ogg`** (16 898 Б) — при копировании появится в `block/`, старое `entity/` остаётся legacy |
| `item/flamethrower_fire.ogg` | в банке как **`entity/flamethrower_fire.ogg`** (28 688 Б, луп 1.64 с) |
| `entity/flesh_amalgam_death.ogg` / `_hurt.ogg` (без суффикса) | в банке только **`_01`**; plain-версии — legacy проекта |
| `hive/hive_block_break_01…03`, `hive/hive_block_place_01…03` | в банке как **`block/hive_block_*`** (6 файлов, 18D) |
| `hive/spawn_hurt_critical_01…04` | в банке как **`hive/hive_spawn_hurt_critical_01…04`** (4 файла, 18D) |
| `entity/flesh_amalgam_smash|roar|step` (без суффикса) | в банке только `_01`/`_02`; позиции из Q7 закрываются алиасами — зона Кодера, файлы уже есть |
| `hallucination/phantom_footsteps.ogg` | **есть** (в остатке 37, не затёрт) — здесь всё в порядке |
| `block/hive_heartbeat.ogg` | есть в банке (40 087 Б, 2.34 с) — но именно это имя фигурировало в §2.4 как «удалить»; копирование его вернёт, и это правильно |
