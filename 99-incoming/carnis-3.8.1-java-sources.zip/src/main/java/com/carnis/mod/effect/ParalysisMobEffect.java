package com.carnis.mod.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public final class ParalysisMobEffect extends MobEffect {
    public ParalysisMobEffect() {
        super(MobEffectCategory.HARMFUL, 0x668A53);
        addAttributeModifier(Attributes.MOVEMENT_SPEED,
                "8da5f8d7-bd27-4b65-86fd-11124abc9201", -1.0D,
                AttributeModifier.Operation.MULTIPLY_TOTAL);
    }
}
