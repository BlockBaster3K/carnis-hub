package com.carnis.mod.entity;

import net.minecraft.util.RandomSource;

/** Persistent, network-synchronized combat variant shared by the four infected archetypes. */
public enum InfectedVariant {
    A(0),
    B(1);

    public static final String NBT_KEY = "CarnisCombatVariant";
    private final int id;

    InfectedVariant(int id) {
        this.id = id;
    }

    public int id() {
        return id;
    }

    public boolean isB() {
        return this == B;
    }

    public static InfectedVariant fromId(int id) {
        return id == B.id ? B : A;
    }

    public static InfectedVariant random(RandomSource random) {
        return random.nextBoolean() ? B : A;
    }
}
