package com.carnis.mod.entity;

import com.carnis.mod.capability.infection.PlayerInfectionApi;
import com.carnis.mod.init.ModEffects;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Entry exposure is per cloud and player, not a repeated dose every tick. */
public final class HiveSporeCloudEntity extends AreaEffectCloud {
    private final Set<UUID> inside = new HashSet<>();
    public HiveSporeCloudEntity(EntityType<? extends AreaEffectCloud> type, Level level) { super(type, level); }
    @Override public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel server) || isRemoved() || tickCount % 5 != 0) return;
        Set<UUID> current = new HashSet<>();
        double radius = getRadius();
        for (LivingEntity living : server.getEntitiesOfClass(LivingEntity.class, getBoundingBox(),
                entity -> entity.isAlive() && !(entity instanceof HivemindLinkedMob)
                        && !(entity instanceof net.minecraft.world.entity.player.Player player
                        && (player.isSpectator() || player.isCreative())))) {
            double dx = living.getX() - getX(), dz = living.getZ() - getZ();
            if (dx * dx + dz * dz > radius * radius) continue;
            current.add(living.getUUID());
            if (!inside.contains(living.getUUID())) {
                living.addEffect(new net.minecraft.world.effect.MobEffectInstance(ModEffects.VENOM.get(), 80, 0));
                if (living instanceof ServerPlayer player) PlayerInfectionApi.addInfection(player, 20F);
            }
        }
        inside.retainAll(current);
        inside.addAll(current);
    }
}
